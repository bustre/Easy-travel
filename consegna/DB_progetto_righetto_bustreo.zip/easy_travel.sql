--
--	Legenda
--	Riga 11: inizio dump database ps;
--	Riga 1330: indice
--	Riga 1546: inizio query
--
--
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Ubuntu 15.4-0ubuntu0.23.04.1)
-- Dumped by pg_dump version 15.4 (Ubuntu 15.4-0ubuntu0.23.04.1)


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3544 (class 1262 OID 16630)
-- Name: Easy Travel; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Easy Travel" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "Easy Travel" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Easy Travel'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 854 (class 1247 OID 16632)
-- Name: genere; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.genere AS ENUM (
    'M',
    'F'
);


ALTER TYPE public.genere OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 223 (class 1259 OID 16711)
-- Name: aeroporto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aeroporto (
    codice character varying(4) NOT NULL,
    id_citta integer NOT NULL
);


ALTER TABLE public.aeroporto OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16700)
-- Name: agenzia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agenzia (
    email character varying(40) NOT NULL,
    password character varying(24) NOT NULL,
    data_iscrizione timestamp without time zone NOT NULL,
    denominazione character varying(40) NOT NULL,
    id_citta integer NOT NULL,
    indirizzo character varying(40) NOT NULL,
    CONSTRAINT agenzia_password_check CHECK (((length((password)::text) >= 8) AND (length((password)::text) <= 24)))
);


ALTER TABLE public.agenzia OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16684)
-- Name: alloggio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alloggio (
    id_citta integer NOT NULL,
    nome character varying(40) NOT NULL,
    stelle integer,
    tipologia character varying(20) NOT NULL,
    id_descrizione integer NOT NULL,
    indirizzo character varying(40) NOT NULL,
    CONSTRAINT alloggio_stelle_check CHECK (((stelle >= 1) AND (stelle <= 5)))
);


ALTER TABLE public.alloggio OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 16828)
-- Name: andata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.andata (
    codice_transazione character varying(16) NOT NULL,
    codice_volo integer NOT NULL,
    CONSTRAINT andata_codice_transazione_check CHECK ((length((codice_transazione)::text) = 16))
);


ALTER TABLE public.andata OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16679)
-- Name: citta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.citta (
    id integer NOT NULL,
    nome character varying(40) NOT NULL,
    stato character varying(35) NOT NULL
);


ALTER TABLE public.citta OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 16644)
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    email character varying(40) NOT NULL,
    password character varying(24) NOT NULL,
    data_iscrizione timestamp without time zone NOT NULL,
    CONSTRAINT cliente_password_check CHECK (((length((password)::text) >= 8) AND (length((password)::text) <= 24)))
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16655)
-- Name: compagnia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compagnia (
    email character varying(40) NOT NULL,
    password character varying(24) NOT NULL,
    data_iscrizione timestamp without time zone NOT NULL,
    nome character varying(40) NOT NULL,
    icao character(4) NOT NULL,
    CONSTRAINT compagnia_password_check CHECK (((length((password)::text) >= 8) AND (length((password)::text) <= 24)))
);


ALTER TABLE public.compagnia OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 16637)
-- Name: dati_cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dati_cliente (
    email_cliente character varying(40) NOT NULL,
    nome character varying(30) NOT NULL,
    cognome character varying(30) NOT NULL,
    data_nascita date NOT NULL,
    sesso public.genere,
    telefono character varying(20)
);


ALTER TABLE public.dati_cliente OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16674)
-- Name: descrizione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.descrizione (
    id integer NOT NULL,
    titolo character varying(40) NOT NULL,
    testo character varying(400) NOT NULL
);


ALTER TABLE public.descrizione OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16661)
-- Name: informazioni_bagagli; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.informazioni_bagagli (
    id integer NOT NULL,
    bagaglio_mano numeric(2,0),
    bagaglio_stiva numeric(2,0),
    CONSTRAINT informazioni_bagagli_check CHECK (((bagaglio_mano >= (0)::numeric) AND (bagaglio_stiva >= (0)::numeric)))
);


ALTER TABLE public.informazioni_bagagli OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 16801)
-- Name: informazioni_trasporto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.informazioni_trasporto (
    codice_transazione character varying(16) NOT NULL,
    prezzo_totale numeric(7,2) NOT NULL,
    CONSTRAINT informazioni_trasporto_check CHECK (((prezzo_totale >= (0)::numeric) AND (length((codice_transazione)::text) = 16)))
);


ALTER TABLE public.informazioni_trasporto OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16753)
-- Name: pacchetto_viaggio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pacchetto_viaggio (
    id integer NOT NULL,
    prezzo numeric(7,2) NOT NULL,
    numero_persone numeric(2,0) NOT NULL,
    disponibilita numeric(2,0) NOT NULL,
    data_partenza date NOT NULL,
    data_ritorno date NOT NULL,
    email_agenzia character varying(40) NOT NULL,
    id_polizza integer NOT NULL,
    id_descrizione integer NOT NULL,
    id_citta_alloggio integer NOT NULL,
    nome_alloggio character varying(40) NOT NULL,
    CONSTRAINT pacchetto_viaggio_check CHECK (((disponibilita >= (1)::numeric) AND (numero_persone >= (1)::numeric) AND (prezzo >= (0)::numeric) AND (data_partenza < data_ritorno)))
);


ALTER TABLE public.pacchetto_viaggio OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16667)
-- Name: polizza; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.polizza (
    id integer NOT NULL,
    titolo character varying(30) NOT NULL,
    descrizione character varying(4000) NOT NULL
);


ALTER TABLE public.polizza OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16779)
-- Name: prenotazione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prenotazione (
    codice_transazione character varying(16) NOT NULL,
    email_cliente character varying(40),
    numero_persone numeric(2,0) NOT NULL,
    id_pacchetto_viaggio integer NOT NULL,
    CONSTRAINT prenotazione_codice_transazione_check CHECK ((length((codice_transazione)::text) = 16)),
    CONSTRAINT prenotazione_numero_persone_check CHECK ((numero_persone >= (1)::numeric))
);


ALTER TABLE public.prenotazione OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 16844)
-- Name: recensione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensione (
    id integer NOT NULL,
    giudizio numeric(1,0) NOT NULL,
    motivazione character varying(350),
    email_cliente character varying(40) NOT NULL,
    data date NOT NULL,
    id_citta_alloggio integer NOT NULL,
    nome_alloggio character varying(40) NOT NULL,
    CONSTRAINT recensione_giudizio_check CHECK (((giudizio >= (0)::numeric) AND (giudizio <= (5)::numeric)))
);


ALTER TABLE public.recensione OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 16812)
-- Name: ritorno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ritorno (
    codice_transazione character varying(16) NOT NULL,
    codice_volo integer NOT NULL,
    CONSTRAINT ritorno_codice_transazione_check CHECK ((length((codice_transazione)::text) = 16))
);


ALTER TABLE public.ritorno OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16721)
-- Name: transazione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transazione (
    codice character varying(16) NOT NULL,
    banca character varying(30) NOT NULL,
    importo numeric(7,2) NOT NULL,
    circuito character varying(20) NOT NULL,
    dataora timestamp without time zone NOT NULL,
    CONSTRAINT transazione_check CHECK (((importo >= (0)::numeric) AND (length((codice)::text) = 16)))
);


ALTER TABLE public.transazione OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 16727)
-- Name: volo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.volo (
    codice integer NOT NULL,
    classe character varying(20) NOT NULL,
    check_in character varying(15) NOT NULL,
    prezzo numeric(7,2) NOT NULL,
    email_compagnia character varying(40) NOT NULL,
    aeroporto_partenza character varying(4) NOT NULL,
    timestamp_partenza timestamp without time zone NOT NULL,
    aeroporto_arrivo character varying(4) NOT NULL,
    timestamp_arrivo timestamp without time zone NOT NULL,
    id_bagagli integer NOT NULL,
    CONSTRAINT volo_check CHECK (((prezzo >= (0)::numeric) AND (timestamp_partenza < timestamp_arrivo)))
);


ALTER TABLE public.volo OWNER TO postgres;

--
-- TOC entry 3530 (class 0 OID 16711)
-- Dependencies: 223
-- Data for Name: aeroporto; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.aeroporto VALUES ('KVXQ', 41);
INSERT INTO public.aeroporto VALUES ('CHVW', 8);
INSERT INTO public.aeroporto VALUES ('LQVF', 29);
INSERT INTO public.aeroporto VALUES ('YSEM', 44);
INSERT INTO public.aeroporto VALUES ('XBHY', 1);
INSERT INTO public.aeroporto VALUES ('TSIR', 47);
INSERT INTO public.aeroporto VALUES ('AUQJ', 24);
INSERT INTO public.aeroporto VALUES ('GKEE', 0);
INSERT INTO public.aeroporto VALUES ('YAAH', 23);
INSERT INTO public.aeroporto VALUES ('MYBE', 21);
INSERT INTO public.aeroporto VALUES ('TZTM', 59);
INSERT INTO public.aeroporto VALUES ('EHCX', 35);
INSERT INTO public.aeroporto VALUES ('DKHH', 4);
INSERT INTO public.aeroporto VALUES ('GXTD', 19);
INSERT INTO public.aeroporto VALUES ('OQOQ', 2);
INSERT INTO public.aeroporto VALUES ('YDHL', 53);
INSERT INTO public.aeroporto VALUES ('LNHV', 52);
INSERT INTO public.aeroporto VALUES ('BAPO', 11);
INSERT INTO public.aeroporto VALUES ('MMCC', 3);
INSERT INTO public.aeroporto VALUES ('HVNO', 49);
INSERT INTO public.aeroporto VALUES ('NQYH', 34);
INSERT INTO public.aeroporto VALUES ('CWOJ', 38);
INSERT INTO public.aeroporto VALUES ('PLAZ', 16);
INSERT INTO public.aeroporto VALUES ('YQXL', 7);
INSERT INTO public.aeroporto VALUES ('ITLG', 56);
INSERT INTO public.aeroporto VALUES ('EYNK', 13);
INSERT INTO public.aeroporto VALUES ('PCWM', 58);
INSERT INTO public.aeroporto VALUES ('JPXU', 5);
INSERT INTO public.aeroporto VALUES ('JURE', 26);
INSERT INTO public.aeroporto VALUES ('ICXW', 50);
INSERT INTO public.aeroporto VALUES ('EWKJ', 54);
INSERT INTO public.aeroporto VALUES ('SPWK', 33);
INSERT INTO public.aeroporto VALUES ('HEKS', 25);
INSERT INTO public.aeroporto VALUES ('LMPZ', 31);
INSERT INTO public.aeroporto VALUES ('ZVXI', 37);
INSERT INTO public.aeroporto VALUES ('CPTP', 36);
INSERT INTO public.aeroporto VALUES ('SEJQ', 43);
INSERT INTO public.aeroporto VALUES ('FKYC', 30);
INSERT INTO public.aeroporto VALUES ('AYBC', 39);


--
-- TOC entry 3529 (class 0 OID 16700)
-- Dependencies: 222
-- Data for Name: agenzia; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agenzia VALUES ('support@EsplorailMondoSegreto.com', 'q_T!O!llz@m6#j(X#bG@KtC6', '2020-12-04 16:33:57', 'Esplora il Mondo Segreto', 2, 'Via Dante Alighieri 23');
INSERT INTO public.agenzia VALUES ('support@SvelailMondo.com', 'CwM#tD9cF!8_0uZ5rYvNrc$5', '2020-02-26 06:12:11', 'Svela il Mondo', 33, 'Via Garofalo 19');
INSERT INTO public.agenzia VALUES ('support@TurismoSostenibile.com', 'j7+1xR_FgT5tGGMA_I*yZVny', '2021-08-17 07:36:51', 'Turismo Sostenibile', 4, 'Piazza San Marco 5');
INSERT INTO public.agenzia VALUES ('support@ViaggiUnici.com', 'Y9Jc7fD)X)JH^ecjSS054QJm', '2022-01-12 17:57:43', 'Viaggi Unici', 28, 'Via Garibaldi 98');
INSERT INTO public.agenzia VALUES ('support@SogniSenzaConfini.com', 'J6HueWAD#Vz8PvDy', '2019-05-30 14:35:51', 'Sogni Senza Confini', 41, 'Via Dante Alighieri 23');
INSERT INTO public.agenzia VALUES ('support@TurismoRuraleMagico.com', 'axJNM4HZHV2zsF@XN@#', '2022-05-23 21:13:32', 'Turismo Rurale Magico', 23, 'Via Garofalo 19');


--
-- TOC entry 3528 (class 0 OID 16684)
-- Dependencies: 221
-- Data for Name: alloggio; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.alloggio VALUES (34, 'Casa Vista Mare', NULL, 'Casa', 43, 'Via Garibaldi 25');
INSERT INTO public.alloggio VALUES (35, 'Hotel Alpino', 5, 'Hotel', 44, 'Via Garibaldi 25');
INSERT INTO public.alloggio VALUES (38, 'Suite dei Sogni', 3, 'Suite', 35, 'Via dei Mille 95');
INSERT INTO public.alloggio VALUES (8, 'Casa Vista Mare', NULL, 'Casa', 39, 'Piazza Duomo 1');
INSERT INTO public.alloggio VALUES (11, 'Hotel Alpino', 1, 'Hotel', 36, 'Via Garibaldi 25');
INSERT INTO public.alloggio VALUES (44, 'Casa Vista Mare', NULL, 'Casa', 32, 'Via Leonardo da Vinci 105');
INSERT INTO public.alloggio VALUES (44, 'Hotel Alpino', NULL, 'Hotel', 38, 'Corso Italia 92');
INSERT INTO public.alloggio VALUES (48, 'Hotel La Cascata', NULL, 'Hotel', 31, 'Corso Italia 92');
INSERT INTO public.alloggio VALUES (49, 'Hotel Aurora', 5, 'Hotel', 41, 'Via Cavour 33');
INSERT INTO public.alloggio VALUES (16, 'Casa Vista Mare', NULL, 'Casa', 42, 'Piazza Navona 10');
INSERT INTO public.alloggio VALUES (19, 'Suite Paradiso Blu', 3, 'Suite', 33, 'Via Dante Alighieri 42');
INSERT INTO public.alloggio VALUES (21, 'Suite Belle Époque', 1, 'Suite', 40, 'Via Carducci 60');
INSERT INTO public.alloggio VALUES (24, 'Casa del Laghetto', NULL, 'Casa', 30, 'Via Alessandro Volta 56');
INSERT INTO public.alloggio VALUES (58, 'Hotel L''Oasi', 5, 'Hotel', 37, 'Via dei Mille 95');
INSERT INTO public.alloggio VALUES (27, 'Suite Nebbia Mattutina', NULL, 'Suite', 34, 'Via Manzoni 78');


--
-- TOC entry 3537 (class 0 OID 16828)
-- Dependencies: 230
-- Data for Name: andata; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.andata VALUES ('WEERAXYFRZHYJCIS', 0);
INSERT INTO public.andata VALUES ('YDVEZQPSEICIEKBV', 2);
INSERT INTO public.andata VALUES ('LFYSOTJMZZOASXWE', 4);
INSERT INTO public.andata VALUES ('MYSHOKOIOOFRGSTL', 6);
INSERT INTO public.andata VALUES ('MYSHOKOIOOFRGSTL', 7);
INSERT INTO public.andata VALUES ('WSUNZTYPXRMJXZFT', 10);
INSERT INTO public.andata VALUES ('YYDGJAZQJEQULYZD', 12);
INSERT INTO public.andata VALUES ('KQFPSMCTAGFWKMKA', 14);
INSERT INTO public.andata VALUES ('WLVYAKYCXBSTRXGA', 16);
INSERT INTO public.andata VALUES ('WLVYAKYCXBSTRXGA', 17);
INSERT INTO public.andata VALUES ('OKGITDIKAGFVGUYX', 20);
INSERT INTO public.andata VALUES ('TDRQMMYWBLAVNXWN', 22);
INSERT INTO public.andata VALUES ('VJUOPXUJBLJWLEWG', 24);
INSERT INTO public.andata VALUES ('FBZFQMADMTFIFYAW', 26);
INSERT INTO public.andata VALUES ('ZJTRLUZQZDLFIWXK', 28);
INSERT INTO public.andata VALUES ('BKSETVKAZHHZTBEY', 30);
INSERT INTO public.andata VALUES ('VNQMNMYBSAHNEORL', 32);
INSERT INTO public.andata VALUES ('LEWCQEZXBWUTGFWG', 34);
INSERT INTO public.andata VALUES ('MGNGPGHMCDAAVQHN', 36);
INSERT INTO public.andata VALUES ('XNNFDZGBRLFRLJIL', 38);
INSERT INTO public.andata VALUES ('SNYSZSLRZOIOEQQK', 40);
INSERT INTO public.andata VALUES ('SNYSZSLRZOIOEQQK', 41);
INSERT INTO public.andata VALUES ('BRHOTIQCYCKSKHFO', 44);
INSERT INTO public.andata VALUES ('NQQZXGTBMQTMQQVX', 46);
INSERT INTO public.andata VALUES ('GMOVYWDKSSMLPHCN', 48);
INSERT INTO public.andata VALUES ('WKINGRJMBOPSKBXV', 50);
INSERT INTO public.andata VALUES ('TUUBFSBUUAMMUJZY', 52);
INSERT INTO public.andata VALUES ('UIMKCSADXXONGGAA', 54);
INSERT INTO public.andata VALUES ('UIMKCSADXXONGGAA', 55);
INSERT INTO public.andata VALUES ('TYAJGYMRKUYWYPQV', 58);
INSERT INTO public.andata VALUES ('UUUPQDMWNIHFNBVR', 60);
INSERT INTO public.andata VALUES ('WXHCLYXDKFNPATWJ', 62);
INSERT INTO public.andata VALUES ('AZAFWRQQUZSSEOKN', 64);
INSERT INTO public.andata VALUES ('AZAFWRQQUZSSEOKN', 65);
INSERT INTO public.andata VALUES ('AZAFWRQQUZSSEOKN', 66);
INSERT INTO public.andata VALUES ('SKVKJJIFAEWSVCUB', 70);
INSERT INTO public.andata VALUES ('VRVWGLRHYIOYFRUE', 72);
INSERT INTO public.andata VALUES ('DVXIFVGIWOEFJYPL', 74);
INSERT INTO public.andata VALUES ('OFSQPAFYXUVOZBGH', 76);
INSERT INTO public.andata VALUES ('CVVBFUDKVUXZCRTH', 78);
INSERT INTO public.andata VALUES ('CVVBFUDKVUXZCRTH', 79);
INSERT INTO public.andata VALUES ('RDONUAHCODAOORAW', 82);
INSERT INTO public.andata VALUES ('RDONUAHCODAOORAW', 83);
INSERT INTO public.andata VALUES ('RDONUAHCODAOORAW', 84);
INSERT INTO public.andata VALUES ('HRAHDITDIBDSILUQ', 88);
INSERT INTO public.andata VALUES ('AMALOTPADYTNMBAY', 90);


--
-- TOC entry 3527 (class 0 OID 16679)
-- Dependencies: 220
-- Data for Name: citta; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.citta VALUES (12, 'Reano', 'Italia');
INSERT INTO public.citta VALUES (51, 'Loreto Aprutino', 'Italia');
INSERT INTO public.citta VALUES (44, 'Fiumicino Di Savignano', 'Italia');
INSERT INTO public.citta VALUES (29, 'Monteforte Irpino', 'Italia');
INSERT INTO public.citta VALUES (32, 'Castelbellino', 'Italia');
INSERT INTO public.citta VALUES (25, 'Valbrevenna', 'Italia');
INSERT INTO public.citta VALUES (52, 'Pila', 'Italia');
INSERT INTO public.citta VALUES (58, 'Saltocchio', 'Italia');
INSERT INTO public.citta VALUES (22, 'Villar Pellice', 'Italia');
INSERT INTO public.citta VALUES (30, 'Tuenno', 'Italia');
INSERT INTO public.citta VALUES (39, 'Tolentino', 'Italia');
INSERT INTO public.citta VALUES (50, 'Molinello', 'Italia');
INSERT INTO public.citta VALUES (27, 'Santa Cecilia Di Eboli', 'Italia');
INSERT INTO public.citta VALUES (46, 'Picerno', 'Italia');
INSERT INTO public.citta VALUES (2, 'Vannullo', 'Italia');
INSERT INTO public.citta VALUES (38, 'Casa Castalda', 'Italia');
INSERT INTO public.citta VALUES (24, 'Vibo Valentia Marina', 'Italia');
INSERT INTO public.citta VALUES (3, 'Villa Motta', 'Italia');
INSERT INTO public.citta VALUES (40, 'Martinengo', 'Italia');
INSERT INTO public.citta VALUES (31, 'Carloforte', 'Italia');
INSERT INTO public.citta VALUES (4, 'Antholz', 'Italia');
INSERT INTO public.citta VALUES (45, 'San Giovanni Di Querciola', 'Italia');
INSERT INTO public.citta VALUES (16, 'San Gabriele Dell''Addolorata', 'Italia');
INSERT INTO public.citta VALUES (8, 'Ulmi', 'Italia');
INSERT INTO public.citta VALUES (53, 'San Nicolo'' Di Celle', 'Italia');
INSERT INTO public.citta VALUES (19, 'Careri', 'Italia');
INSERT INTO public.citta VALUES (54, 'Barcarola', 'Italia');
INSERT INTO public.citta VALUES (11, 'Tarvisio', 'Italia');
INSERT INTO public.citta VALUES (56, 'Laureana Cilento', 'Italia');
INSERT INTO public.citta VALUES (49, 'Beverino', 'Italia');
INSERT INTO public.citta VALUES (33, 'Vinovo', 'Italia');
INSERT INTO public.citta VALUES (17, 'Gergei', 'Italia');
INSERT INTO public.citta VALUES (10, 'Zattaglia', 'Italia');
INSERT INTO public.citta VALUES (6, 'Citerna', 'Italia');
INSERT INTO public.citta VALUES (13, 'Rapone', 'Italia');
INSERT INTO public.citta VALUES (5, 'Luras', 'Italia');
INSERT INTO public.citta VALUES (59, 'Stazione Morrovalle', 'Italia');
INSERT INTO public.citta VALUES (34, 'Isola Fossara', 'Italia');
INSERT INTO public.citta VALUES (18, 'Pozzolengo', 'Italia');
INSERT INTO public.citta VALUES (55, 'Costa Calcinara', 'Italia');
INSERT INTO public.citta VALUES (0, 'Straulas', 'Italia');
INSERT INTO public.citta VALUES (14, 'Dego', 'Italia');
INSERT INTO public.citta VALUES (57, 'Spilinga', 'Italia');
INSERT INTO public.citta VALUES (43, 'Montedoro', 'Italia');
INSERT INTO public.citta VALUES (26, 'Niscemi', 'Italia');
INSERT INTO public.citta VALUES (37, 'San Fili', 'Italia');
INSERT INTO public.citta VALUES (9, 'Barriera Del Bosco', 'Italia');
INSERT INTO public.citta VALUES (23, 'Cascia', 'Italia');
INSERT INTO public.citta VALUES (42, 'Sant''Arpino', 'Italia');
INSERT INTO public.citta VALUES (21, 'Dragoni', 'Italia');
INSERT INTO public.citta VALUES (20, 'Ville Di Corsano', 'Italia');
INSERT INTO public.citta VALUES (1, 'Campo Di Giove', 'Italia');
INSERT INTO public.citta VALUES (7, 'Novoli', 'Italia');
INSERT INTO public.citta VALUES (47, 'Giave', 'Italia');
INSERT INTO public.citta VALUES (28, 'Pomaia', 'Italia');
INSERT INTO public.citta VALUES (41, 'Badia A Cerreto', 'Italia');
INSERT INTO public.citta VALUES (35, 'Agliana', 'Italia');
INSERT INTO public.citta VALUES (48, 'Gannano', 'Italia');
INSERT INTO public.citta VALUES (15, 'Reggio Emilia', 'Italia');
INSERT INTO public.citta VALUES (36, 'Loano', 'Italia');


--
-- TOC entry 3522 (class 0 OID 16644)
-- Dependencies: 215
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.cliente VALUES ('Rosina73_Saragat@lambda.mail.it', '+DgFTrtE2LP0hCl', '2019-08-13 22:31:46');
INSERT INTO public.cliente VALUES ('Teresa.Guidotti@fastmail.org', 't$5LaesZ(', '2019-04-14 17:26:01');
INSERT INTO public.cliente VALUES ('Adamo67.Jovinelli@fastmail.org', '_U2KfGXhc_v_B34DyJ_', '2019-05-31 14:50:14');
INSERT INTO public.cliente VALUES ('Annunziata.Fornaciari@email.com', '!D5faXbx', '2019-04-29 04:37:35');
INSERT INTO public.cliente VALUES ('Valerio.Foà@fastmail.org', 'Sgs81U_)((MTAYNuOPOw', '2018-09-18 13:45:18');
INSERT INTO public.cliente VALUES ('Bettina.Cortese@email.com', '^3hn#Ot)&', '2019-08-13 06:50:10');
INSERT INTO public.cliente VALUES ('Donna.Pozzecco@lambda.mail.it', 'z$R3Jx8x', '2019-03-18 09:53:56');
INSERT INTO public.cliente VALUES ('Erika81.Asmundo@lambda.mail.it', '#^ijjUd3gmi6VYEf', '2018-12-26 01:21:56');
INSERT INTO public.cliente VALUES ('Fausto.Abba@email.com', ')uw9wmjh#SJwBoa+', '2018-12-27 18:57:18');
INSERT INTO public.cliente VALUES ('Giulio.Simeoni@fastmail.org', ')+#@1nVy', '2019-03-08 11:42:32');
INSERT INTO public.cliente VALUES ('Virginia.Piacentini@email.com', 'nCgT%tpl_+0zqzOA', '2019-07-05 06:14:33');
INSERT INTO public.cliente VALUES ('Enzo79_Campano@lambda.mail.it', ')cqEtsOOb7', '2019-05-30 18:03:09');
INSERT INTO public.cliente VALUES ('Evangelista100.Giacometti@fastmail.org', '@A(JTuWq*j8#L', '2019-08-21 11:16:14');
INSERT INTO public.cliente VALUES ('Annibale.Boezio@fastmail.org', '$2CB+ajP', '2018-12-19 20:15:52');
INSERT INTO public.cliente VALUES ('Marina82_Bosurgi@email.com', ')iNXbVsi)Ahn^0R+', '2018-09-10 09:39:16');
INSERT INTO public.cliente VALUES ('Lara66_Polesel@email.com', 'Qww0vUwe37*0Ua_', '2019-04-22 10:06:18');
INSERT INTO public.cliente VALUES ('Roberta.Cociarelli@email.com', 'bvG!FvWp1(0w)xEN9$', '2018-10-07 10:49:05');
INSERT INTO public.cliente VALUES ('Rosina.Pavanello@lambda.mail.it', 'N&0xIq4_', '2019-02-28 05:52:15');
INSERT INTO public.cliente VALUES ('Berenice.Luxardo@email.com', '9^561Q^HCI*tNRye', '2018-12-24 12:08:46');
INSERT INTO public.cliente VALUES ('Alessandro.Leblanc@fastmail.org', 'ceuzIvQGn6+0lv5b', '2019-07-23 14:25:43');
INSERT INTO public.cliente VALUES ('daniel92@example.net', 'd))0uMAE6YZRF!xcKF', '2019-02-18 15:41:33');
INSERT INTO public.cliente VALUES ('Fulvio85.Passalacqua@fastmail.org', 'd1vBxe9o*G9ht', '2018-09-12 13:14:10');
INSERT INTO public.cliente VALUES ('Alphons88_Trentini@fastmail.org', '3Q1!3LBc', '2018-09-15 01:34:35');
INSERT INTO public.cliente VALUES ('Paoletta.Travaglio@lambda.mail.it', '%7JFz7jzP', '2019-06-17 23:05:14');
INSERT INTO public.cliente VALUES ('Simone.Modugno@fastmail.org', 'myI%xBn)@wI!7hyzX2X2Ac', '2019-04-29 20:26:06');
INSERT INTO public.cliente VALUES ('Antonella72_Taccola@email.com', '%G0v5YnvN_rW4d', '2019-04-23 10:13:53');
INSERT INTO public.cliente VALUES ('Licia78.Donatoni@email.com', 'jB4mY6d^)^', '2019-07-18 08:13:14');
INSERT INTO public.cliente VALUES ('Fabia.Bonino@lambda.mail.it', '_PL*znEgot4b', '2019-03-22 20:49:27');
INSERT INTO public.cliente VALUES ('Micheletto.Mazzacurati@fastmail.org', '#5X7RgzM$', '2019-03-11 15:44:32');
INSERT INTO public.cliente VALUES ('Achille.Salandra@email.com', 'AiYS+egci)i8y(r$6QV7*A', '2018-10-01 03:19:31');


--
-- TOC entry 3523 (class 0 OID 16655)
-- Dependencies: 216
-- Data for Name: compagnia; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.compagnia VALUES ('team@SkySprintAirlines.com', 'Bow@HbzZI__8P0stef_gQmdd', '2020-05-21 23:33:56', 'SkySprint Airlines', 'RPVM');
INSERT INTO public.compagnia VALUES ('team@RiverRideCruises.com', '&i6CAOi3HKZIdmVEUT8mHu_&', '2020-03-08 05:08:28', 'RiverRide Cruises', 'SLVR');
INSERT INTO public.compagnia VALUES ('team@AquaJetFerries.com', 'M#t_l9lEy+2Ed@gU51iJU5Mp', '2019-08-06 07:06:26', 'AquaJet Ferries', 'LDZA');


--
-- TOC entry 3521 (class 0 OID 16637)
-- Dependencies: 214
-- Data for Name: dati_cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.dati_cliente VALUES ('Rosina73_Saragat@lambda.mail.it', 'Rosina', 'Saragat', '1992-05-22', 'F', '+39 089840761');
INSERT INTO public.dati_cliente VALUES ('Teresa.Guidotti@fastmail.org', 'Teresa', 'Guidotti', '1973-12-18', 'F', '+39 245551590');
INSERT INTO public.dati_cliente VALUES ('Adamo67.Jovinelli@fastmail.org', 'Adamo', 'Jovinelli', '1986-11-16', 'M', '+39 312502394');
INSERT INTO public.dati_cliente VALUES ('Annunziata.Fornaciari@email.com', 'Annunziata', 'Fornaciari', '1974-07-01', 'F', '+39 003510562');
INSERT INTO public.dati_cliente VALUES ('Valerio.Foà@fastmail.org', 'Valerio', 'Foà', '1980-12-31', 'M', '+39 576081160');
INSERT INTO public.dati_cliente VALUES ('Bettina.Cortese@email.com', 'Bettina', 'Cortese', '1994-06-02', 'F', '+39 478978443');
INSERT INTO public.dati_cliente VALUES ('Donna.Pozzecco@lambda.mail.it', 'Donna', 'Pozzecco', '1996-08-13', 'F', '+39 357492208');
INSERT INTO public.dati_cliente VALUES ('Erika81.Asmundo@lambda.mail.it', 'Erika', 'Asmundo', '1981-02-23', NULL, '+39 778514296');
INSERT INTO public.dati_cliente VALUES ('Fausto.Abba@email.com', 'Fausto', 'Abba', '1974-02-15', 'M', '+39 448885536');
INSERT INTO public.dati_cliente VALUES ('Giulio.Simeoni@fastmail.org', 'Giulio', 'Simeoni', '1995-06-24', 'M', '+39 159179533');
INSERT INTO public.dati_cliente VALUES ('Virginia.Piacentini@email.com', 'Virginia', 'Piacentini', '1992-04-12', 'F', '+39 719659342');
INSERT INTO public.dati_cliente VALUES ('Enzo79_Campano@lambda.mail.it', 'Enzo', 'Campano', '1984-06-28', 'M', '+39 082492694');
INSERT INTO public.dati_cliente VALUES ('Evangelista100.Giacometti@fastmail.org', 'Evangelista', 'Giacometti', '1998-03-31', 'F', '+39 151150552');
INSERT INTO public.dati_cliente VALUES ('Annibale.Boezio@fastmail.org', 'Annibale', 'Boezio', '1994-01-11', 'M', '+39 769930024');
INSERT INTO public.dati_cliente VALUES ('Marina82_Bosurgi@email.com', 'Marina', 'Bosurgi', '1997-07-17', 'F', '+39 027142787');
INSERT INTO public.dati_cliente VALUES ('Lara66_Polesel@email.com', 'Lara', 'Polesel', '1992-08-21', 'F', '+39 735919155');
INSERT INTO public.dati_cliente VALUES ('Roberta.Cociarelli@email.com', 'Roberta', 'Cociarelli', '1993-06-04', 'F', '+39 262235833');
INSERT INTO public.dati_cliente VALUES ('Rosina.Pavanello@lambda.mail.it', 'Rosina', 'Pavanello', '1977-02-01', NULL, '+39 659387784');
INSERT INTO public.dati_cliente VALUES ('Berenice.Luxardo@email.com', 'Berenice', 'Luxardo', '1998-08-30', NULL, '+39 296111330');
INSERT INTO public.dati_cliente VALUES ('Alessandro.Leblanc@fastmail.org', 'Alessandro', 'Leblanc', '2001-07-25', 'M', '+39 909255445');
INSERT INTO public.dati_cliente VALUES ('daniel92@example.net', 'Antonino', 'Cherubini', '1979-12-20', 'M', '+39 623758257');
INSERT INTO public.dati_cliente VALUES ('Fulvio85.Passalacqua@fastmail.org', 'Fulvio', 'Passalacqua', '1986-12-31', 'M', '+39 537510074');
INSERT INTO public.dati_cliente VALUES ('Alphons88_Trentini@fastmail.org', 'Alphons', 'Trentini', '1992-06-10', 'M', '+39 077706777');
INSERT INTO public.dati_cliente VALUES ('Paoletta.Travaglio@lambda.mail.it', 'Paoletta', 'Travaglio', '1980-07-10', 'F', '+39 764303921');
INSERT INTO public.dati_cliente VALUES ('Simone.Modugno@fastmail.org', 'Simone', 'Modugno', '1974-05-28', 'M', '+39 714285124');
INSERT INTO public.dati_cliente VALUES ('Antonella72_Taccola@email.com', 'Antonella', 'Taccola', '1986-10-26', 'F', '+39 017200992');
INSERT INTO public.dati_cliente VALUES ('Licia78.Donatoni@email.com', 'Licia', 'Donatoni', '1974-11-25', 'F', '+39 321730086');
INSERT INTO public.dati_cliente VALUES ('Fabia.Bonino@lambda.mail.it', 'Fabia', 'Bonino', '1977-08-25', 'F', '+39 207698456');
INSERT INTO public.dati_cliente VALUES ('Micheletto.Mazzacurati@fastmail.org', 'Micheletto', 'Mazzacurati', '1994-10-27', 'M', '+39 153230282');
INSERT INTO public.dati_cliente VALUES ('Achille.Salandra@email.com', 'Achille', 'Salandra', '1976-01-22', 'M', '+39 485183216');


--
-- TOC entry 3526 (class 0 OID 16674)
-- Dependencies: 219
-- Data for Name: descrizione; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.descrizione VALUES (0, 'Rilassati al Mare', 'Goditi una vacanza rilassante al mare con spiagge di sabbia dorata e acque cristalline.');
INSERT INTO public.descrizione VALUES (1, 'Esplora una Città Vibrante', 'Scopri una città piena di vita, con monumenti storici, ristoranti gourmet e vita notturna vivace.');
INSERT INTO public.descrizione VALUES (2, 'Avventura in Montagna', 'Fai trekking tra le montagne, respira l''aria fresca e ammira panorami mozzafiato.');
INSERT INTO public.descrizione VALUES (3, 'Vacanza Culturale', 'Immergiti nella cultura locale con visite a musei, gallerie d''arte e siti storici.');
INSERT INTO public.descrizione VALUES (4, 'Rilassamento al Mare', 'Trascorri giornate di puro relax sulla spiaggia e rilassati in resort di lusso.');
INSERT INTO public.descrizione VALUES (5, 'Esplorazione Urbana', 'Passeggia per le strade affollate, assapora la cucina locale e scopri segreti nascosti della città.');
INSERT INTO public.descrizione VALUES (6, 'Escursioni in Montagna', 'Affronta escursioni impegnative e conquista le vette più alte.');
INSERT INTO public.descrizione VALUES (7, 'Viaggio Enogastronomico', 'Delizia il tuo palato con prelibatezze locali e degusta vini pregiati.');
INSERT INTO public.descrizione VALUES (8, 'Divertimento in Spiaggia', 'Partecipa a sport acquatici, feste in spiaggia e attività all''aperto.');
INSERT INTO public.descrizione VALUES (9, 'Arte e Cultura Urbana', 'Esplora gallerie d''arte contemporanea, teatri e quartieri culturali.');
INSERT INTO public.descrizione VALUES (10, 'Relax Costiero', 'Goditi il suono delle onde e le brezze marine in un tranquillo rifugio sulla costa.');
INSERT INTO public.descrizione VALUES (11, 'Esplorazione Storica', 'Scopri la storia antica della regione visitando siti archeologici e castelli medievali.');
INSERT INTO public.descrizione VALUES (12, 'Sfide in Montagna', 'Affronta percorsi avventurosi, arrampicate su roccia e gite in bicicletta in montagna.');
INSERT INTO public.descrizione VALUES (13, 'Viaggio Gastronomico', 'Assaggia la cucina locale attraverso tour culinari guidati e lezioni di cucina.');
INSERT INTO public.descrizione VALUES (14, 'Spiaggia e Sport Acquatici', 'Pratica sport acquatici come il surf, il nuoto e il kayak nelle acque cristalline.');
INSERT INTO public.descrizione VALUES (15, 'Vita Notturna Cittadina', 'Esperienza notti indimenticabili con club, bar e spettacoli in città.');
INSERT INTO public.descrizione VALUES (16, 'Percorsi Panoramici in Montagna', 'Segui percorsi panoramici tra valli e cime montane mozzafiato.');
INSERT INTO public.descrizione VALUES (17, 'Esperienza Teatrale', 'Assisti a spettacoli teatrali, concerti e opere d''arte in città culturali.');
INSERT INTO public.descrizione VALUES (18, 'Soggiorno di Lusso in Riva al Mare', 'Vivi in ​​un resort di lusso con servizio personalizzato a due passi dalla spiaggia.');
INSERT INTO public.descrizione VALUES (19, 'Esplorazione Architettonica', 'Ammira l''architettura unica delle città con edifici storici e moderni.');
INSERT INTO public.descrizione VALUES (20, 'Ski e Neve', 'Scia sulle piste innevate e rilassati in accoglienti chalet di montagna.');
INSERT INTO public.descrizione VALUES (21, 'Cultura e Musica', 'Immergiti nella scena musicale e culturale della città con concerti e festival.');
INSERT INTO public.descrizione VALUES (22, 'Resort All-Inclusive', 'Goditi un soggiorno senza pensieri in un resort all-inclusive con tutte le comodità.');
INSERT INTO public.descrizione VALUES (23, 'Tour Enologici', 'Esplora le cantine locali e degusta i migliori vini e prodotti tipici della regione.');
INSERT INTO public.descrizione VALUES (24, 'Avventure Subacquee', 'Scopri il mondo sottomarino con immersioni subacquee e snorkeling.');
INSERT INTO public.descrizione VALUES (25, 'Arte Moderna e Contemporanea', 'Visita musei d''arte moderna e contemporanea nelle città d''avanguardia.');
INSERT INTO public.descrizione VALUES (26, 'Relax Termale in Montagna', 'Rilassati nelle sorgenti termali naturali in un ambiente di montagna sereno.');
INSERT INTO public.descrizione VALUES (27, 'Scoperta Storica e Religiosa', 'Esplora siti storici e luoghi di culto in città ricche di storia.');
INSERT INTO public.descrizione VALUES (28, 'Spiaggia e Yoga', 'Rigenera corpo e mente con lezioni di yoga sulla spiaggia al sorgere del sole.');
INSERT INTO public.descrizione VALUES (29, 'Avventura in Montagna Estiva', 'Esplora le montagne durante l''estate con escursioni e sport all''aperto.');
INSERT INTO public.descrizione VALUES (30, 'Hotel Bella Vista', 'Un hotel di lusso con vista panoramica sulla baia.');
INSERT INTO public.descrizione VALUES (31, 'Casa delle Montagne', 'Una casa accogliente nelle Alpi con vista sulle montagne.');
INSERT INTO public.descrizione VALUES (32, 'Suite di lusso al centro', 'Una suite elegante nel cuore della città.');
INSERT INTO public.descrizione VALUES (33, 'Appartamento sul mare', 'Un appartamento affacciato sulla spiaggia di sabbia bianca.');
INSERT INTO public.descrizione VALUES (34, 'Chalet di montagna', 'Un accogliente chalet di legno nelle montagne.');
INSERT INTO public.descrizione VALUES (35, 'Hotel Elegante', 'Un hotel di lusso nel centro della città.');
INSERT INTO public.descrizione VALUES (36, 'Suite vista mare', 'Una suite di lusso con vista panoramica sul mare.');
INSERT INTO public.descrizione VALUES (37, 'Appartamento nel centro storico', 'Un appartamento nel cuore della città antica.');
INSERT INTO public.descrizione VALUES (38, 'Villa tranquilla', 'Una villa spaziosa con giardino, perfetta per una vacanza rilassante.');
INSERT INTO public.descrizione VALUES (39, 'Resort sulla spiaggia', 'Un resort a cinque stelle direttamente sulla spiaggia.');
INSERT INTO public.descrizione VALUES (40, 'Appartamento moderno', 'Un appartamento moderno con una vista panoramica sulla città.');
INSERT INTO public.descrizione VALUES (41, 'Chalet di montagna accogliente', 'Un chalet di montagna con camino per una fuga invernale.');
INSERT INTO public.descrizione VALUES (42, 'Suite di lusso con jacuzzi', 'Una suite di lusso con jacuzzi privata.');
INSERT INTO public.descrizione VALUES (43, 'Appartamento vista mare', 'Un appartamento con vista sul mare e accesso diretto alla spiaggia.');
INSERT INTO public.descrizione VALUES (44, 'Hotel nel centro storico', 'Un affascinante hotel nel cuore del centro storico.');
INSERT INTO public.descrizione VALUES (45, 'Villa sulle colline', 'Una villa con piscina immersa nelle colline toscane.');


--
-- TOC entry 3524 (class 0 OID 16661)
-- Dependencies: 217
-- Data for Name: informazioni_bagagli; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.informazioni_bagagli VALUES (11, NULL, NULL);
INSERT INTO public.informazioni_bagagli VALUES (2, NULL, 13);
INSERT INTO public.informazioni_bagagli VALUES (6, NULL, 18);
INSERT INTO public.informazioni_bagagli VALUES (8, NULL, 12);
INSERT INTO public.informazioni_bagagli VALUES (14, NULL, 11);
INSERT INTO public.informazioni_bagagli VALUES (1, 5, NULL);
INSERT INTO public.informazioni_bagagli VALUES (10, NULL, 10);
INSERT INTO public.informazioni_bagagli VALUES (7, 12, 8);
INSERT INTO public.informazioni_bagagli VALUES (13, 8, 6);
INSERT INTO public.informazioni_bagagli VALUES (0, NULL, 14);
INSERT INTO public.informazioni_bagagli VALUES (4, NULL, 19);
INSERT INTO public.informazioni_bagagli VALUES (3, 11, NULL);
INSERT INTO public.informazioni_bagagli VALUES (5, 4, NULL);


--
-- TOC entry 3535 (class 0 OID 16801)
-- Dependencies: 228
-- Data for Name: informazioni_trasporto; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.informazioni_trasporto VALUES ('WEERAXYFRZHYJCIS', 93.72);
INSERT INTO public.informazioni_trasporto VALUES ('YDVEZQPSEICIEKBV', 334.78);
INSERT INTO public.informazioni_trasporto VALUES ('LFYSOTJMZZOASXWE', 89.67);
INSERT INTO public.informazioni_trasporto VALUES ('MYSHOKOIOOFRGSTL', 164.76);
INSERT INTO public.informazioni_trasporto VALUES ('WSUNZTYPXRMJXZFT', 267.94);
INSERT INTO public.informazioni_trasporto VALUES ('YYDGJAZQJEQULYZD', 61.79);
INSERT INTO public.informazioni_trasporto VALUES ('KQFPSMCTAGFWKMKA', 77.63);
INSERT INTO public.informazioni_trasporto VALUES ('WLVYAKYCXBSTRXGA', 138.64);
INSERT INTO public.informazioni_trasporto VALUES ('OKGITDIKAGFVGUYX', 159.00);
INSERT INTO public.informazioni_trasporto VALUES ('TDRQMMYWBLAVNXWN', 79.75);
INSERT INTO public.informazioni_trasporto VALUES ('VJUOPXUJBLJWLEWG', 407.01);
INSERT INTO public.informazioni_trasporto VALUES ('FBZFQMADMTFIFYAW', 78.32);
INSERT INTO public.informazioni_trasporto VALUES ('ZJTRLUZQZDLFIWXK', 93.13);
INSERT INTO public.informazioni_trasporto VALUES ('BKSETVKAZHHZTBEY', 86.70);
INSERT INTO public.informazioni_trasporto VALUES ('VNQMNMYBSAHNEORL', 101.30);
INSERT INTO public.informazioni_trasporto VALUES ('LEWCQEZXBWUTGFWG', 201.11);
INSERT INTO public.informazioni_trasporto VALUES ('MGNGPGHMCDAAVQHN', 61.53);
INSERT INTO public.informazioni_trasporto VALUES ('XNNFDZGBRLFRLJIL', 240.77);
INSERT INTO public.informazioni_trasporto VALUES ('SNYSZSLRZOIOEQQK', 131.68);
INSERT INTO public.informazioni_trasporto VALUES ('BRHOTIQCYCKSKHFO', 176.25);
INSERT INTO public.informazioni_trasporto VALUES ('NQQZXGTBMQTMQQVX', 125.23);
INSERT INTO public.informazioni_trasporto VALUES ('GMOVYWDKSSMLPHCN', 133.12);
INSERT INTO public.informazioni_trasporto VALUES ('WKINGRJMBOPSKBXV', 87.78);
INSERT INTO public.informazioni_trasporto VALUES ('TUUBFSBUUAMMUJZY', 108.95);
INSERT INTO public.informazioni_trasporto VALUES ('UIMKCSADXXONGGAA', 153.87);
INSERT INTO public.informazioni_trasporto VALUES ('TYAJGYMRKUYWYPQV', 73.13);
INSERT INTO public.informazioni_trasporto VALUES ('UUUPQDMWNIHFNBVR', 201.45);
INSERT INTO public.informazioni_trasporto VALUES ('WXHCLYXDKFNPATWJ', 183.95);
INSERT INTO public.informazioni_trasporto VALUES ('AZAFWRQQUZSSEOKN', 1174.47);
INSERT INTO public.informazioni_trasporto VALUES ('SKVKJJIFAEWSVCUB', 68.34);
INSERT INTO public.informazioni_trasporto VALUES ('VRVWGLRHYIOYFRUE', 104.00);
INSERT INTO public.informazioni_trasporto VALUES ('DVXIFVGIWOEFJYPL', 221.08);
INSERT INTO public.informazioni_trasporto VALUES ('OFSQPAFYXUVOZBGH', 50.85);
INSERT INTO public.informazioni_trasporto VALUES ('CVVBFUDKVUXZCRTH', 157.12);
INSERT INTO public.informazioni_trasporto VALUES ('RDONUAHCODAOORAW', 547.00);
INSERT INTO public.informazioni_trasporto VALUES ('HRAHDITDIBDSILUQ', 87.63);
INSERT INTO public.informazioni_trasporto VALUES ('AMALOTPADYTNMBAY', 97.52);


--
-- TOC entry 3533 (class 0 OID 16753)
-- Dependencies: 226
-- Data for Name: pacchetto_viaggio; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.pacchetto_viaggio VALUES (0, 1337.19, 4, 1, '2023-04-10', '2023-04-16', 'support@TurismoRuraleMagico.com', 1, 1, 38, 'Suite dei Sogni');
INSERT INTO public.pacchetto_viaggio VALUES (1, 528.07, 2, 2, '2020-05-15', '2020-05-28', 'support@ViaggiUnici.com', 3, 3, 44, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (2, 1125.56, 4, 6, '2023-05-25', '2023-05-31', 'support@SogniSenzaConfini.com', 0, 10, 8, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (3, 860.73, 4, 2, '2021-11-10', '2021-11-20', 'support@EsplorailMondoSegreto.com', 3, 24, 24, 'Casa del Laghetto');
INSERT INTO public.pacchetto_viaggio VALUES (4, 422.66, 4, 5, '2021-05-26', '2021-06-09', 'support@SvelailMondo.com', 0, 9, 21, 'Suite Belle Époque');
INSERT INTO public.pacchetto_viaggio VALUES (5, 639.85, 1, 6, '2022-03-31', '2022-04-13', 'support@TurismoSostenibile.com', 2, 17, 35, 'Hotel Alpino');
INSERT INTO public.pacchetto_viaggio VALUES (6, 453.31, 2, 3, '2022-06-21', '2022-06-30', 'support@ViaggiUnici.com', 0, 28, 24, 'Casa del Laghetto');
INSERT INTO public.pacchetto_viaggio VALUES (7, 523.95, 2, 4, '2020-07-18', '2020-07-30', 'support@EsplorailMondoSegreto.com', 3, 12, 49, 'Hotel Aurora');
INSERT INTO public.pacchetto_viaggio VALUES (8, 493.75, 2, 6, '2021-07-10', '2021-07-19', 'support@SogniSenzaConfini.com', 2, 28, 19, 'Suite Paradiso Blu');
INSERT INTO public.pacchetto_viaggio VALUES (9, 619.24, 1, 3, '2022-09-03', '2022-09-08', 'support@EsplorailMondoSegreto.com', 3, 5, 35, 'Hotel Alpino');
INSERT INTO public.pacchetto_viaggio VALUES (10, 781.08, 1, 6, '2022-07-27', '2022-08-05', 'support@ViaggiUnici.com', 3, 24, 34, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (11, 1041.78, 4, 2, '2021-05-20', '2021-05-27', 'support@EsplorailMondoSegreto.com', 2, 10, 8, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (12, 978.09, 1, 4, '2020-10-13', '2020-10-27', 'support@ViaggiUnici.com', 2, 4, 8, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (13, 887.63, 2, 5, '2019-10-01', '2019-10-04', 'support@EsplorailMondoSegreto.com', 0, 3, 38, 'Suite dei Sogni');
INSERT INTO public.pacchetto_viaggio VALUES (14, 482.77, 4, 2, '2022-02-27', '2022-03-06', 'support@SvelailMondo.com', 1, 1, 44, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (15, 1285.74, 3, 2, '2020-03-25', '2020-04-04', 'support@TurismoRuraleMagico.com', 0, 11, 21, 'Suite Belle Époque');
INSERT INTO public.pacchetto_viaggio VALUES (16, 1383.45, 4, 2, '2023-07-28', '2023-08-03', 'support@EsplorailMondoSegreto.com', 3, 3, 16, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (17, 503.38, 4, 6, '2021-04-24', '2021-04-29', 'support@TurismoRuraleMagico.com', 3, 14, 11, 'Hotel Alpino');
INSERT INTO public.pacchetto_viaggio VALUES (18, 450.21, 4, 2, '2020-05-22', '2020-05-28', 'support@SvelailMondo.com', 0, 25, 44, 'Casa Vista Mare');
INSERT INTO public.pacchetto_viaggio VALUES (19, 1117.39, 3, 6, '2023-06-05', '2023-06-13', 'support@SogniSenzaConfini.com', 0, 4, 34, 'Casa Vista Mare');


--
-- TOC entry 3525 (class 0 OID 16667)
-- Dependencies: 218
-- Data for Name: polizza; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.polizza VALUES (1, 'Polizza di Viaggio Completa', 'La Polizza di Viaggio Completa è la scelta ideale per chi desidera massima tranquillità durante il proprio viaggio. Questa polizza offre una copertura estesa che si estende ben oltre le situazioni di base, garantendoti una protezione completa.

Copertura Principale:
1. Assistenza Medica all''Estero: La polizza copre le spese mediche necessarie dovute a malattie o infortuni durante il viaggio, inclusa l''evacuazione medica di emergenza in qualsiasi parte del mondo.
2. Annullamento del Viaggio: Se il tuo viaggio viene annullato per qualsiasi motivo, sarai rimborsato per le spese non rimborsabili sostenute per la prenotazione del viaggio.
3. Ritardo o Cancellazione del Volo: In caso di ritardi o cancellazioni dei voli, la polizza ti coprirà per le spese extra sostenute, come alloggio di lusso, pasti e trasporti alternativi.
4. Bagaglio Smarrito o Danneggiato: Se il tuo bagaglio viene smarrito o danneggiato durante il viaggio, la polizza fornirà una copertura completa per il recupero o la sostituzione dei tuoi effetti personali, incluso il valore degli oggetti di valore.
5. Assistenza Legale: Se incontri situazioni legali inaspettate durante il viaggio, questa polizza offre un ampio supporto legale e copre le spese legali.
6. Copertura per Attività Speciali: Questa polizza include coperture speciali per attività avventurose come sport estremi, immersioni subacquee e alpinismo.

Periodo di Copertura: La Polizza di Viaggio Completa è disponibile per il periodo specifico del biaggio
Assistenza 24/7: Siamo disponibili 24 ore al giorno, 7 giorni alla settimana, per fornirti supporto e assistenza in caso di emergenza ovunque tu sia nel mondo.

Con la Polizza di Viaggio Completa, viaggiare diventa un''esperienza senza preoccupazioni, sapendo che sei protetto in qualsiasi situazione imprevista che potresti incontrare durante il tuo viaggio.');
INSERT INTO public.polizza VALUES (2, 'Polizza di Viaggio Covid19', 'La Polizza di Viaggio con Copertura COVID-19 è stata progettata per affrontare le sfide specifiche legate alla pandemia di COVID-19 durante i tuoi viaggi. Questa polizza offre una copertura speciale per garantire la tua sicurezza e la tranquillità durante il viaggio in un periodo di incertezza.

Copertura Principale:

1. Copertura per Spese Mediche COVID-19: La polizza copre le spese mediche necessarie dovute al COVID-19 durante il viaggio, inclusi i test diagnostici, il trattamento e, se necessario, l''evacuazione medica.
2. Annullamento del Viaggio a Causa del COVID-19: Se il tuo viaggio viene annullato a causa del COVID-19, sarai rimborsato per le spese non rimborsabili sostenute per la prenotazione del viaggio.
3. Quarantena Obbligatoria: Se sei costretto a sottoporsi a quarantena durante il viaggio a causa del COVID-19, la polizza coprirà le spese extra sostenute, come alloggio e pasti.
4. Assistenza Legale COVID-19: Se incontri situazioni legali inaspettate legate al COVID-19 durante il viaggio, questa polizza può fornire assistenza legale e coprire le spese legali necessarie.

Periodo di Copertura: La Polizza di Viaggio con Copertura COVID-19 è disponibile per il periodo specifico del tuo viaggio e può essere estesa per coprire eventuali cambiamenti nei tuoi piani dovuti al COVID-19.
Assistenza 24/7: Siamo disponibili 24 ore al giorno, 7 giorni alla settimana, per fornirti supporto e assistenza in caso di emergenza legata al COVID-19 durante il viaggio.

Con la Polizza di Viaggio con Copertura COVID-19, puoi esplorare il mondo con la sicurezza di una copertura completa contro gli imprevisti legati alla pandemia.
');
INSERT INTO public.polizza VALUES (3, 'Polizza di Viaggio Pets', 'Descrizione: La Polizza di Viaggio per Animali Domestici è pensata per i viaggiatori che desiderano portare con sé i loro amici a quattro zampe. Questa polizza fornisce una copertura speciale per la salute e la sicurezza dei tuoi animali domestici durante il viaggio.

Copertura Principale:
1. Assistenza Medica all''Estero: La polizza copre le spese mediche necessarie dovute a malattie o infortuni durante il viaggio. Questa copertura include anche l''evacuazione medica di emergenza, se necessario.
2. Assistenza Veterinaria all''Estero: La polizza copre le spese veterinarie necessarie dovute a malattie o infortuni del tuo animale domestico durante il viaggio, inclusa la possibilità di visite presso le cliniche veterinarie locali.
3. Annullamento del Viaggio a Causa dell''Animale Domestico: Se devi annullare il viaggio a causa di un infortunio o una malattia del tuo animale domestico, sarai rimborsato per le spese non rimborsabili sostenute per la prenotazione del viaggio.
4. Custodia Temporanea dell''Animale: Se, a seguito di un infortunio o di un problema di salute, non puoi prenderti cura del tuo animale domestico durante il viaggio, la polizza coprirà le spese relative alla custodia temporanea.
5. Assistenza Legale: Se incontri situazioni legali inaspettate riguardanti te o il tuo animale domestico durante il viaggio, questa polizza può fornire assistenza legale e coprire le spese legali necessarie.

Periodo di Copertura: La Polizza di Viaggio per Animali Domestici è disponibile per il periodo specifico del tuo viaggio.
Assistenza 24/7: Siamo disponibili 24 ore al giorno, 7 giorni alla settimana, per fornirti supporto e assistenza in caso di emergenza legata al tuo animale domestico durante il viaggio.

Con la Polizza di Viaggio per Animali Domestici, puoi goderti il tuo viaggio con la sicurezza di avere il benessere del tuo amico peloso al centro delle tue preoccupazioni.
');
INSERT INTO public.polizza VALUES (0, 'Polizza di Viaggio Base', 'La Polizza di Viaggio Base è progettata per offrire una copertura essenziale e affidabile durante il tuo viaggio. Che tu stia pianificando una vacanza breve o un''avventura più lunga, questa polizza ti fornisce la tranquillità di sapere che sei protetto contro una serie di imprevisti.

Copertura Principale:
1. Assistenza Medica all''Estero: La polizza copre le spese mediche necessarie dovute a malattie o infortuni durante il viaggio. Questa copertura include anche l''evacuazione medica di emergenza, se necessario.
2. Annullamento del Viaggio: Se il tuo viaggio viene annullato per motivi coperti dalla polizza, sarai rimborsato per le spese non rimborsabili sostenute per la prenotazione del viaggio.
3. Ritardo o Cancellazione del Volo: In caso di ritardi o cancellazioni dei voli, la polizza ti coprirà per le spese extra sostenute, come alloggio e pasti.
4. Bagaglio Smarrito o Danneggiato: Se il tuo bagaglio viene smarrito o danneggiato durante il viaggio, la polizza fornirà una copertura per il suo recupero o la sostituzione dei tuoi effetti personali.
5. Assistenza Legale: Se incontri situazioni legali inaspettate durante il viaggio, questa polizza può fornire assistenza legale e coprire le spese legali necessarie.

Periodo di Copertura: La polizza di viaggio base è disponibile per un periodo specifico che puoi selezionare in base alle tue esigenze. È possibile scegliere una copertura per un singolo viaggio o una copertura multi-viaggio valida per un anno intero.
Assistenza 24/7: Siamo disponibili 24 ore al giorno, 7 giorni alla settimana, per fornirti supporto e assistenza in caso di emergenza ovunque tu sia nel mondo.
Pacchetto Fondamentale per la Sicurezza: La Polizza di Viaggio Base è il tuo compagno fidato per garantire una protezione fondamentale durante il viaggio. Con tariffe accessibili e una copertura essenziale, puoi viaggiare con fiducia sapendo che sei protetto in caso di imprevisti.

Ti consigliamo di esaminare attentamente i dettagli del contratto e le condizioni di copertura specifiche per garantire che soddisfi tutte le tue esigenze e aspettative durante il viaggio.
');


--
-- TOC entry 3534 (class 0 OID 16779)
-- Dependencies: 227
-- Data for Name: prenotazione; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.prenotazione VALUES ('WEERAXYFRZHYJCIS', 'Bettina.Cortese@email.com', 1, 12);
INSERT INTO public.prenotazione VALUES ('YDVEZQPSEICIEKBV', 'Antonella72_Taccola@email.com', 3, 14);
INSERT INTO public.prenotazione VALUES ('LFYSOTJMZZOASXWE', 'Lara66_Polesel@email.com', 1, 1);
INSERT INTO public.prenotazione VALUES ('MYSHOKOIOOFRGSTL', 'Paoletta.Travaglio@lambda.mail.it', 1, 3);
INSERT INTO public.prenotazione VALUES ('WSUNZTYPXRMJXZFT', 'Achille.Salandra@email.com', 3, 15);
INSERT INTO public.prenotazione VALUES ('YYDGJAZQJEQULYZD', 'Achille.Salandra@email.com', 1, 6);
INSERT INTO public.prenotazione VALUES ('KQFPSMCTAGFWKMKA', 'Berenice.Luxardo@email.com', 1, 5);
INSERT INTO public.prenotazione VALUES ('WLVYAKYCXBSTRXGA', 'Annibale.Boezio@fastmail.org', 1, 5);
INSERT INTO public.prenotazione VALUES ('OKGITDIKAGFVGUYX', 'Simone.Modugno@fastmail.org', 3, 15);
INSERT INTO public.prenotazione VALUES ('TDRQMMYWBLAVNXWN', 'Rosina.Pavanello@lambda.mail.it', 1, 5);
INSERT INTO public.prenotazione VALUES ('LOHFWYBEPAJXIBTP', 'Giulio.Simeoni@fastmail.org', 1, 1);
INSERT INTO public.prenotazione VALUES ('VJUOPXUJBLJWLEWG', 'Virginia.Piacentini@email.com', 4, 17);
INSERT INTO public.prenotazione VALUES ('FBZFQMADMTFIFYAW', 'daniel92@example.net', 1, 5);
INSERT INTO public.prenotazione VALUES ('ZJTRLUZQZDLFIWXK', 'Evangelista100.Giacometti@fastmail.org', 1, 18);
INSERT INTO public.prenotazione VALUES ('BKSETVKAZHHZTBEY', 'Berenice.Luxardo@email.com', 1, 10);
INSERT INTO public.prenotazione VALUES ('VNQMNMYBSAHNEORL', 'Adamo67.Jovinelli@fastmail.org', 2, 13);
INSERT INTO public.prenotazione VALUES ('LEWCQEZXBWUTGFWG', 'Erika81.Asmundo@lambda.mail.it', 2, 16);
INSERT INTO public.prenotazione VALUES ('MGNGPGHMCDAAVQHN', 'Lara66_Polesel@email.com', 1, 10);
INSERT INTO public.prenotazione VALUES ('XNNFDZGBRLFRLJIL', 'Bettina.Cortese@email.com', 3, 18);
INSERT INTO public.prenotazione VALUES ('SNYSZSLRZOIOEQQK', 'Alphons88_Trentini@fastmail.org', 1, 6);
INSERT INTO public.prenotazione VALUES ('EAPIOKCSEARGEYQP', 'Paoletta.Travaglio@lambda.mail.it', 2, 2);
INSERT INTO public.prenotazione VALUES ('BRHOTIQCYCKSKHFO', 'Berenice.Luxardo@email.com', 2, 8);
INSERT INTO public.prenotazione VALUES ('NQQZXGTBMQTMQQVX', 'Donna.Pozzecco@lambda.mail.it', 1, 10);
INSERT INTO public.prenotazione VALUES ('GMOVYWDKSSMLPHCN', 'Virginia.Piacentini@email.com', 2, 6);
INSERT INTO public.prenotazione VALUES ('WKINGRJMBOPSKBXV', 'Micheletto.Mazzacurati@fastmail.org', 1, 3);
INSERT INTO public.prenotazione VALUES ('TUUBFSBUUAMMUJZY', 'Licia78.Donatoni@email.com', 1, 17);
INSERT INTO public.prenotazione VALUES ('UIMKCSADXXONGGAA', 'Simone.Modugno@fastmail.org', 1, 10);
INSERT INTO public.prenotazione VALUES ('TYAJGYMRKUYWYPQV', 'Micheletto.Mazzacurati@fastmail.org', 1, 2);
INSERT INTO public.prenotazione VALUES ('UUUPQDMWNIHFNBVR', 'Micheletto.Mazzacurati@fastmail.org', 2, 13);
INSERT INTO public.prenotazione VALUES ('WXHCLYXDKFNPATWJ', 'Annunziata.Fornaciari@email.com', 2, 4);
INSERT INTO public.prenotazione VALUES ('AZAFWRQQUZSSEOKN', 'Fausto.Abba@email.com', 4, 11);
INSERT INTO public.prenotazione VALUES ('SKVKJJIFAEWSVCUB', 'Fabia.Bonino@lambda.mail.it', 1, 2);
INSERT INTO public.prenotazione VALUES ('VRVWGLRHYIOYFRUE', 'Micheletto.Mazzacurati@fastmail.org', 1, 17);
INSERT INTO public.prenotazione VALUES ('DVXIFVGIWOEFJYPL', 'Alphons88_Trentini@fastmail.org', 2, 11);
INSERT INTO public.prenotazione VALUES ('OFSQPAFYXUVOZBGH', 'Fabia.Bonino@lambda.mail.it', 1, 9);
INSERT INTO public.prenotazione VALUES ('CVVBFUDKVUXZCRTH', 'Annunziata.Fornaciari@email.com', 1, 16);
INSERT INTO public.prenotazione VALUES ('RDONUAHCODAOORAW', 'Annunziata.Fornaciari@email.com', 2, 8);
INSERT INTO public.prenotazione VALUES ('AQRRNEKXJYBEWOCC', 'Rosina.Pavanello@lambda.mail.it', 1, 9);
INSERT INTO public.prenotazione VALUES ('HRAHDITDIBDSILUQ', 'Bettina.Cortese@email.com', 1, 2);
INSERT INTO public.prenotazione VALUES ('AMALOTPADYTNMBAY', 'Micheletto.Mazzacurati@fastmail.org', 1, 10);


--
-- TOC entry 3538 (class 0 OID 16844)
-- Dependencies: 231
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.recensione VALUES (0, 3, NULL, 'Antonella72_Taccola@email.com', '2022-04-02', 44, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (1, 3, NULL, 'Lara66_Polesel@email.com', '2020-06-06', 44, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (2, 3, NULL, 'Paoletta.Travaglio@lambda.mail.it', '2021-12-02', 24, 'Casa del Laghetto');
INSERT INTO public.recensione VALUES (3, 2, NULL, 'Achille.Salandra@email.com', '2020-04-20', 21, 'Suite Belle Époque');
INSERT INTO public.recensione VALUES (4, 4, NULL, 'Achille.Salandra@email.com', '2022-07-18', 24, 'Casa del Laghetto');
INSERT INTO public.recensione VALUES (5, 2, 'Servizio scadente e cibo mediocre, delusione totale.', 'Annibale.Boezio@fastmail.org', '2022-05-06', 35, 'Hotel Alpino');
INSERT INTO public.recensione VALUES (6, 1, NULL, 'Simone.Modugno@fastmail.org', '2020-05-02', 21, 'Suite Belle Époque');
INSERT INTO public.recensione VALUES (7, 3, 'Luogo incantevole ma il servizio era mediocre.', 'Rosina.Pavanello@lambda.mail.it', '2022-05-06', 35, 'Hotel Alpino');
INSERT INTO public.recensione VALUES (8, 1, 'Un''esperienza terribile, non consigliato a nessuno.', 'Virginia.Piacentini@email.com', '2021-05-04', 11, 'Hotel Alpino');
INSERT INTO public.recensione VALUES (9, 2, NULL, 'daniel92@example.net', '2022-04-13', 35, 'Hotel Alpino');
INSERT INTO public.recensione VALUES (10, 2, 'Soggiorno deludente, non all''altezza delle aspettative.', 'Berenice.Luxardo@email.com', '2022-08-13', 34, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (11, 4, NULL, 'Erika81.Asmundo@lambda.mail.it', '2023-08-07', 16, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (12, 3, 'Non è stato male, ma potrebbe migliorare.', 'Bettina.Cortese@email.com', '2020-06-15', 44, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (13, 2, 'Mi aspettavo di più, non è stato all''altezza delle aspettative.', 'Berenice.Luxardo@email.com', '2021-08-18', 19, 'Suite Paradiso Blu');
INSERT INTO public.recensione VALUES (14, 2, 'Servizio scadente e cibo mediocre, delusione totale.', 'Donna.Pozzecco@lambda.mail.it', '2022-09-02', 34, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (15, 3, 'Non male, ma c''erano alcune carenze.', 'Virginia.Piacentini@email.com', '2022-07-21', 24, 'Casa del Laghetto');
INSERT INTO public.recensione VALUES (16, 1, NULL, 'Licia78.Donatoni@email.com', '2021-05-24', 11, 'Hotel Alpino');
INSERT INTO public.recensione VALUES (17, 3, 'Non è stato male, ma potrebbe migliorare.', 'Micheletto.Mazzacurati@fastmail.org', '2019-10-13', 38, 'Suite dei Sogni');
INSERT INTO public.recensione VALUES (18, 2, NULL, 'Fausto.Abba@email.com', '2021-06-03', 8, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (19, 1, 'Non ci tornerei mai, è stata una delusione totale.', 'Fabia.Bonino@lambda.mail.it', '2023-06-04', 8, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (20, 1, NULL, 'Micheletto.Mazzacurati@fastmail.org', '2021-05-20', 11, 'Hotel Alpino');
INSERT INTO public.recensione VALUES (21, 1, NULL, 'Annunziata.Fornaciari@email.com', '2021-07-21', 19, 'Suite Paradiso Blu');
INSERT INTO public.recensione VALUES (22, 3, 'Non era male, ma c''era sicuramente margine per migliorare.', 'Rosina.Pavanello@lambda.mail.it', '2022-09-18', 35, 'Hotel Alpino');
INSERT INTO public.recensione VALUES (23, 2, 'Soggiorno deludente, non all''altezza delle aspettative.', 'Bettina.Cortese@email.com', '2023-06-17', 8, 'Casa Vista Mare');
INSERT INTO public.recensione VALUES (24, 1, 'Strutture vecchie e sporche, non tornerò mai più.', 'Micheletto.Mazzacurati@fastmail.org', '2022-08-19', 34, 'Casa Vista Mare');


--
-- TOC entry 3536 (class 0 OID 16812)
-- Dependencies: 229
-- Data for Name: ritorno; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ritorno VALUES ('WEERAXYFRZHYJCIS', 1);
INSERT INTO public.ritorno VALUES ('YDVEZQPSEICIEKBV', 3);
INSERT INTO public.ritorno VALUES ('LFYSOTJMZZOASXWE', 5);
INSERT INTO public.ritorno VALUES ('MYSHOKOIOOFRGSTL', 8);
INSERT INTO public.ritorno VALUES ('MYSHOKOIOOFRGSTL', 9);
INSERT INTO public.ritorno VALUES ('WSUNZTYPXRMJXZFT', 11);
INSERT INTO public.ritorno VALUES ('YYDGJAZQJEQULYZD', 13);
INSERT INTO public.ritorno VALUES ('KQFPSMCTAGFWKMKA', 15);
INSERT INTO public.ritorno VALUES ('WLVYAKYCXBSTRXGA', 18);
INSERT INTO public.ritorno VALUES ('WLVYAKYCXBSTRXGA', 19);
INSERT INTO public.ritorno VALUES ('OKGITDIKAGFVGUYX', 21);
INSERT INTO public.ritorno VALUES ('TDRQMMYWBLAVNXWN', 23);
INSERT INTO public.ritorno VALUES ('VJUOPXUJBLJWLEWG', 25);
INSERT INTO public.ritorno VALUES ('FBZFQMADMTFIFYAW', 27);
INSERT INTO public.ritorno VALUES ('ZJTRLUZQZDLFIWXK', 29);
INSERT INTO public.ritorno VALUES ('BKSETVKAZHHZTBEY', 31);
INSERT INTO public.ritorno VALUES ('VNQMNMYBSAHNEORL', 33);
INSERT INTO public.ritorno VALUES ('LEWCQEZXBWUTGFWG', 35);
INSERT INTO public.ritorno VALUES ('MGNGPGHMCDAAVQHN', 37);
INSERT INTO public.ritorno VALUES ('XNNFDZGBRLFRLJIL', 39);
INSERT INTO public.ritorno VALUES ('SNYSZSLRZOIOEQQK', 42);
INSERT INTO public.ritorno VALUES ('SNYSZSLRZOIOEQQK', 43);
INSERT INTO public.ritorno VALUES ('BRHOTIQCYCKSKHFO', 45);
INSERT INTO public.ritorno VALUES ('NQQZXGTBMQTMQQVX', 47);
INSERT INTO public.ritorno VALUES ('GMOVYWDKSSMLPHCN', 49);
INSERT INTO public.ritorno VALUES ('WKINGRJMBOPSKBXV', 51);
INSERT INTO public.ritorno VALUES ('TUUBFSBUUAMMUJZY', 53);
INSERT INTO public.ritorno VALUES ('UIMKCSADXXONGGAA', 56);
INSERT INTO public.ritorno VALUES ('UIMKCSADXXONGGAA', 57);
INSERT INTO public.ritorno VALUES ('TYAJGYMRKUYWYPQV', 59);
INSERT INTO public.ritorno VALUES ('UUUPQDMWNIHFNBVR', 61);
INSERT INTO public.ritorno VALUES ('WXHCLYXDKFNPATWJ', 63);
INSERT INTO public.ritorno VALUES ('AZAFWRQQUZSSEOKN', 67);
INSERT INTO public.ritorno VALUES ('AZAFWRQQUZSSEOKN', 68);
INSERT INTO public.ritorno VALUES ('AZAFWRQQUZSSEOKN', 69);
INSERT INTO public.ritorno VALUES ('SKVKJJIFAEWSVCUB', 71);
INSERT INTO public.ritorno VALUES ('VRVWGLRHYIOYFRUE', 73);
INSERT INTO public.ritorno VALUES ('DVXIFVGIWOEFJYPL', 75);
INSERT INTO public.ritorno VALUES ('OFSQPAFYXUVOZBGH', 77);
INSERT INTO public.ritorno VALUES ('CVVBFUDKVUXZCRTH', 80);
INSERT INTO public.ritorno VALUES ('CVVBFUDKVUXZCRTH', 81);
INSERT INTO public.ritorno VALUES ('RDONUAHCODAOORAW', 85);
INSERT INTO public.ritorno VALUES ('RDONUAHCODAOORAW', 86);
INSERT INTO public.ritorno VALUES ('RDONUAHCODAOORAW', 87);
INSERT INTO public.ritorno VALUES ('HRAHDITDIBDSILUQ', 89);
INSERT INTO public.ritorno VALUES ('AMALOTPADYTNMBAY', 91);


--
-- TOC entry 3531 (class 0 OID 16721)
-- Dependencies: 224
-- Data for Name: transazione; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.transazione VALUES ('WEERAXYFRZHYJCIS', 'LibraBank', 1071.81, 'TrustFund Express', '2020-09-12 13:11:41');
INSERT INTO public.transazione VALUES ('YDVEZQPSEICIEKBV', 'RisparmiSicuri', 1783.10, 'TransaFondo', '2022-02-10 03:00:50');
INSERT INTO public.transazione VALUES ('LFYSOTJMZZOASXWE', 'GlobalTrust Bank', 617.74, 'PagamentiPlus', '2020-04-14 21:36:31');
INSERT INTO public.transazione VALUES ('MYSHOKOIOOFRGSTL', 'TrustWave', 1025.49, 'CashWave', '2021-10-18 03:42:00');
INSERT INTO public.transazione VALUES ('WSUNZTYPXRMJXZFT', 'CapitalSecure', 4125.16, 'MonetaShield', '2020-02-27 09:48:49');
INSERT INTO public.transazione VALUES ('YYDGJAZQJEQULYZD', 'Hamlin, Hamlin & McGill (HHM)', 515.10, 'SecurePay Connect', '2022-05-24 23:16:36');
INSERT INTO public.transazione VALUES ('KQFPSMCTAGFWKMKA', 'SafeInvestment', 717.48, 'SecureTransact', '2022-03-17 09:54:59');
INSERT INTO public.transazione VALUES ('WLVYAKYCXBSTRXGA', 'FinanzaProgress', 778.49, 'FinanzaTrust', '2022-03-09 19:03:24');
INSERT INTO public.transazione VALUES ('OKGITDIKAGFVGUYX', 'Sunrise Savings', 4016.22, 'FinanzaTrust', '2020-02-26 11:48:38');
INSERT INTO public.transazione VALUES ('TDRQMMYWBLAVNXWN', 'LibraBank', 719.60, 'PagamentiPlus', '2022-03-14 03:32:18');
INSERT INTO public.transazione VALUES ('LOHFWYBEPAJXIBTP', 'Liberty Bank', 528.07, 'FinanzaTrust', '2020-04-21 13:35:21');
INSERT INTO public.transazione VALUES ('VJUOPXUJBLJWLEWG', 'LibraBank', 2420.53, 'FinanzaTrust', '2021-04-13 22:19:46');
INSERT INTO public.transazione VALUES ('FBZFQMADMTFIFYAW', 'SavingsFirst', 718.17, 'FinanzaTrust', '2022-03-22 00:05:29');
INSERT INTO public.transazione VALUES ('ZJTRLUZQZDLFIWXK', 'RisparmiSicuri', 543.34, 'CapitalNet', '2020-04-28 16:12:10');
INSERT INTO public.transazione VALUES ('BKSETVKAZHHZTBEY', 'FirstChoiceFinance', 867.78, 'CashWave', '2022-07-05 09:31:10');
INSERT INTO public.transazione VALUES ('VNQMNMYBSAHNEORL', 'CapitalSecure', 1876.56, 'BancaLink Global', '2019-09-17 00:33:11');
INSERT INTO public.transazione VALUES ('LEWCQEZXBWUTGFWG', 'SavingsFirst', 2968.01, 'FinanzaSwift', '2023-06-29 21:49:46');
INSERT INTO public.transazione VALUES ('MGNGPGHMCDAAVQHN', 'WealthLink Bank', 842.61, 'EasyExchange', '2022-07-17 10:08:12');
INSERT INTO public.transazione VALUES ('XNNFDZGBRLFRLJIL', 'Hamlin, Hamlin & McGill (HHM)', 1591.40, 'MonetaShield', '2020-05-11 16:17:26');
INSERT INTO public.transazione VALUES ('SNYSZSLRZOIOEQQK', 'HarborTrust', 584.99, 'SecureTransact', '2022-05-26 09:10:33');
INSERT INTO public.transazione VALUES ('EAPIOKCSEARGEYQP', 'FirstChoiceFinance', 2251.12, 'MonetaSecure', '2023-05-07 20:58:11');
INSERT INTO public.transazione VALUES ('BRHOTIQCYCKSKHFO', 'NexaFinance', 1163.75, 'SecureTransact', '2021-06-18 04:40:46');
INSERT INTO public.transazione VALUES ('NQQZXGTBMQTMQQVX', 'Liberty Bank', 906.31, 'MonetaShield', '2022-07-04 08:00:12');
INSERT INTO public.transazione VALUES ('GMOVYWDKSSMLPHCN', 'FirstChoiceFinance', 1039.74, 'FinanzaLink', '2022-05-27 21:04:28');
INSERT INTO public.transazione VALUES ('WKINGRJMBOPSKBXV', 'SafeInvestment', 948.51, 'MonetaShield', '2021-10-24 03:14:53');
INSERT INTO public.transazione VALUES ('TUUBFSBUUAMMUJZY', 'EcoCredit', 612.33, 'CapitalCrossing', '2021-04-09 08:02:36');
INSERT INTO public.transazione VALUES ('UIMKCSADXXONGGAA', 'GlobalTrust Bank', 934.95, 'PagamentiPlus', '2022-07-18 22:37:37');
INSERT INTO public.transazione VALUES ('TYAJGYMRKUYWYPQV', 'CapitalSecure', 1198.69, 'EasyExchange', '2023-04-29 14:34:53');
INSERT INTO public.transazione VALUES ('UUUPQDMWNIHFNBVR', 'Prosperity Bank', 1976.71, 'BancaLink Global', '2019-09-06 21:48:02');
INSERT INTO public.transazione VALUES ('WXHCLYXDKFNPATWJ', 'HarborTrust', 1029.27, 'FinanzaLink', '2021-04-26 09:02:02');
INSERT INTO public.transazione VALUES ('AZAFWRQQUZSSEOKN', 'GlobalTrust Bank', 5341.59, 'SecurePay Connect', '2021-04-19 07:08:10');
INSERT INTO public.transazione VALUES ('SKVKJJIFAEWSVCUB', 'TrustWave', 1193.90, 'CashWave', '2023-05-09 07:27:44');
INSERT INTO public.transazione VALUES ('VRVWGLRHYIOYFRUE', 'SmartBank', 607.38, 'MoneyMover', '2021-03-28 01:19:31');
INSERT INTO public.transazione VALUES ('DVXIFVGIWOEFJYPL', 'RisparmiSicuri', 2304.64, 'MoneyMover', '2021-04-19 06:18:30');
INSERT INTO public.transazione VALUES ('OFSQPAFYXUVOZBGH', 'InnovaBank', 670.09, 'TransaFondo', '2022-08-12 13:02:08');
INSERT INTO public.transazione VALUES ('CVVBFUDKVUXZCRTH', 'NexaFinance', 1540.57, 'CapitalCrossing', '2023-07-11 06:54:34');
INSERT INTO public.transazione VALUES ('RDONUAHCODAOORAW', 'SmartBank', 1534.50, 'BancaLink Global', '2021-06-24 19:39:47');
INSERT INTO public.transazione VALUES ('AQRRNEKXJYBEWOCC', 'Sunrise Savings', 619.24, 'BancaLink Global', '2022-08-11 08:03:51');
INSERT INTO public.transazione VALUES ('HRAHDITDIBDSILUQ', 'Liberty Bank', 1213.19, 'CapitalCrossing', '2023-04-25 08:12:32');
INSERT INTO public.transazione VALUES ('AMALOTPADYTNMBAY', 'SmartBank', 878.60, 'FinanzaLink', '2022-06-28 07:18:26');


--
-- TOC entry 3532 (class 0 OID 16727)
-- Dependencies: 225
-- Data for Name: volo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.volo VALUES (0, 'Business Deluxe', 'Aeroporto', 59.33, 'team@RiverRideCruises.com', 'KVXQ', '2020-10-13 04:29:36', 'CHVW', '2020-10-13 06:24:58.873536', 7);
INSERT INTO public.volo VALUES (2, 'Prima Classe', 'Online', 67.96, 'team@SkySprintAirlines.com', 'LQVF', '2022-02-27 03:52:05', 'YSEM', '2022-02-27 06:14:51.142452', 5);
INSERT INTO public.volo VALUES (4, 'Economy Plus', 'Online', 26.31, 'team@SkySprintAirlines.com', 'XBHY', '2020-05-15 07:26:14', 'YSEM', '2020-05-15 10:38:00.972285', 14);
INSERT INTO public.volo VALUES (6, 'Economy Standard', 'Online', 26.72, 'team@SkySprintAirlines.com', 'TSIR', '2021-11-10 23:47:01', 'XBHY', '2021-11-11 01:23:26.400771', 5);
INSERT INTO public.volo VALUES (7, 'Business Deluxe', 'Online', 63.79, 'team@SkySprintAirlines.com', 'XBHY', '2021-11-11 02:15:26.400771', 'AUQJ', '2021-11-11 04:54:06.06044', 5);
INSERT INTO public.volo VALUES (10, 'Business', 'Online', 50.57, 'team@SkySprintAirlines.com', 'YAAH', '2020-03-25 18:12:19', 'MYBE', '2020-03-25 19:55:21.729174', 1);
INSERT INTO public.volo VALUES (12, 'Economy Standard', 'Aeroporto', 22.29, 'team@AquaJetFerries.com', 'TZTM', '2022-06-21 14:40:26', 'AUQJ', '2022-06-21 16:54:37.396396', 3);
INSERT INTO public.volo VALUES (14, 'Premium Economy', 'Aeroporto', 32.48, 'team@SkySprintAirlines.com', 'GKEE', '2022-03-31 01:00:01', 'EHCX', '2022-03-31 03:08:44.504557', 4);
INSERT INTO public.volo VALUES (16, 'Economy', 'Online', 38.50, 'team@RiverRideCruises.com', 'DKHH', '2022-03-31 21:17:49', 'GXTD', '2022-03-31 23:41:18.285661', 11);
INSERT INTO public.volo VALUES (17, 'Economy Standard', 'Online', 31.07, 'team@RiverRideCruises.com', 'GXTD', '2022-04-01 00:30:18.285661', 'EHCX', '2022-04-01 03:12:12.299466', 11);
INSERT INTO public.volo VALUES (20, 'Economy', 'Online', 22.64, 'team@AquaJetFerries.com', 'OQOQ', '2020-03-25 11:47:54', 'MYBE', '2020-03-25 14:06:42.574293', 14);
INSERT INTO public.volo VALUES (22, 'Premium Economy', 'Online', 31.36, 'team@AquaJetFerries.com', 'YDHL', '2022-03-31 03:44:00', 'EHCX', '2022-03-31 05:46:13.312234', 11);
INSERT INTO public.volo VALUES (24, 'Business Deluxe', 'Online', 69.10, 'team@AquaJetFerries.com', 'LNHV', '2021-04-24 18:38:23', 'BAPO', '2021-04-24 20:35:54.097954', 8);
INSERT INTO public.volo VALUES (26, 'Economy Plus', 'Aeroporto', 36.48, 'team@SkySprintAirlines.com', 'BAPO', '2022-03-31 11:42:40', 'EHCX', '2022-03-31 13:31:48.259088', 0);
INSERT INTO public.volo VALUES (28, 'Premium Economy', 'Online', 26.87, 'team@RiverRideCruises.com', 'MMCC', '2020-05-22 18:51:20', 'YSEM', '2020-05-22 20:27:15.069532', 11);
INSERT INTO public.volo VALUES (30, 'Business Deluxe', 'Aeroporto', 58.03, 'team@AquaJetFerries.com', 'HVNO', '2022-07-27 01:47:54', 'NQYH', '2022-07-27 04:06:37.41668', 7);
INSERT INTO public.volo VALUES (32, 'Economy', 'Online', 30.44, 'team@RiverRideCruises.com', 'LQVF', '2019-10-01 01:01:54', 'CWOJ', '2019-10-01 03:06:27.999045', 3);
INSERT INTO public.volo VALUES (34, 'Prima Classe', 'Online', 59.80, 'team@RiverRideCruises.com', 'LNHV', '2023-07-28 21:29:10', 'PLAZ', '2023-07-28 23:38:15.814067', 5);
INSERT INTO public.volo VALUES (36, 'Economy Standard', 'Aeroporto', 23.18, 'team@SkySprintAirlines.com', 'YQXL', '2022-07-27 23:43:25', 'NQYH', '2022-07-28 01:14:40.859027', 10);
INSERT INTO public.volo VALUES (38, 'Business Deluxe', 'Aeroporto', 53.21, 'team@AquaJetFerries.com', 'TZTM', '2020-05-22 18:14:50', 'YSEM', '2020-05-22 20:07:45.954686', 4);
INSERT INTO public.volo VALUES (40, 'Premium Economy', 'Online', 29.72, 'team@SkySprintAirlines.com', 'ITLG', '2022-06-21 22:53:27', 'YSEM', '2022-06-22 01:13:00.367036', 7);
INSERT INTO public.volo VALUES (41, 'Economy Plus', 'Online', 37.61, 'team@SkySprintAirlines.com', 'YSEM', '2022-06-22 01:35:00.367036', 'AUQJ', '2022-06-22 04:28:16.893629', 7);
INSERT INTO public.volo VALUES (44, 'Business', 'Online', 53.60, 'team@SkySprintAirlines.com', 'PCWM', '2021-07-10 01:58:04', 'GXTD', '2021-07-10 04:12:01.037163', 5);
INSERT INTO public.volo VALUES (46, 'Business Deluxe', 'Aeroporto', 54.72, 'team@RiverRideCruises.com', 'JPXU', '2022-07-27 06:11:21', 'NQYH', '2022-07-27 08:25:37.655196', 14);
INSERT INTO public.volo VALUES (48, 'Economy', 'Online', 39.80, 'team@AquaJetFerries.com', 'YSEM', '2022-06-21 15:37:17', 'AUQJ', '2022-06-21 17:21:58.070849', 7);
INSERT INTO public.volo VALUES (50, 'Premium Economy', 'Online', 41.00, 'team@AquaJetFerries.com', 'EHCX', '2021-11-10 08:10:27', 'AUQJ', '2021-11-10 10:01:14.452349', 8);
INSERT INTO public.volo VALUES (52, 'Business Deluxe', 'Online', 49.05, 'team@AquaJetFerries.com', 'YAAH', '2021-04-24 16:24:27', 'BAPO', '2021-04-24 18:01:11.012194', 2);
INSERT INTO public.volo VALUES (54, 'Economy Standard', 'Online', 28.66, 'team@RiverRideCruises.com', 'TZTM', '2022-07-27 01:20:58', 'JURE', '2022-07-27 03:47:55.709165', 0);
INSERT INTO public.volo VALUES (55, 'Business', 'Aeroporto', 55.50, 'team@RiverRideCruises.com', 'JURE', '2022-07-27 04:42:55.709165', 'NQYH', '2022-07-27 07:10:46.744191', 0);
INSERT INTO public.volo VALUES (58, 'Economy Standard', 'Aeroporto', 28.87, 'team@SkySprintAirlines.com', 'YQXL', '2023-05-25 23:51:13', 'CHVW', '2023-05-26 01:54:12.249447', 8);
INSERT INTO public.volo VALUES (60, 'Business', 'Aeroporto', 40.74, 'team@RiverRideCruises.com', 'YDHL', '2019-10-01 11:02:34', 'CWOJ', '2019-10-01 13:21:12.837768', 0);
INSERT INTO public.volo VALUES (62, 'Premium Economy', 'Online', 41.35, 'team@RiverRideCruises.com', 'EWKJ', '2021-05-26 22:00:07', 'MYBE', '2021-05-26 23:47:28.021641', 2);
INSERT INTO public.volo VALUES (64, 'Prima Classe', 'Online', 45.30, 'team@SkySprintAirlines.com', 'YQXL', '2021-05-20 12:20:16', 'SPWK', '2021-05-20 15:15:12.093537', 7);
INSERT INTO public.volo VALUES (65, 'Business Deluxe', 'Aeroporto', 63.76, 'team@SkySprintAirlines.com', 'SPWK', '2021-05-20 15:58:12.093537', 'NQYH', '2021-05-20 19:23:41.632681', 7);
INSERT INTO public.volo VALUES (66, 'Prima Classe', 'Aeroporto', 45.80, 'team@SkySprintAirlines.com', 'NQYH', '2021-05-20 20:18:41.632681', 'CHVW', '2021-05-20 23:41:37.240533', 7);
INSERT INTO public.volo VALUES (70, 'Economy Plus', 'Aeroporto', 28.19, 'team@RiverRideCruises.com', 'HEKS', '2023-05-25 18:20:05', 'CHVW', '2023-05-25 21:09:59.757538', 0);
INSERT INTO public.volo VALUES (72, 'Prima Classe', 'Aeroporto', 44.60, 'team@SkySprintAirlines.com', 'EHCX', '2021-04-24 06:03:59', 'BAPO', '2021-04-24 08:02:38.781004', 14);
INSERT INTO public.volo VALUES (74, 'Prima Classe', 'Online', 78.88, 'team@SkySprintAirlines.com', 'TSIR', '2021-05-20 20:24:36', 'CHVW', '2021-05-20 22:08:02.587582', 1);
INSERT INTO public.volo VALUES (76, 'Economy Plus', 'Online', 27.54, 'team@AquaJetFerries.com', 'LMPZ', '2022-09-03 05:27:05', 'EHCX', '2022-09-03 07:44:42.921998', 14);
INSERT INTO public.volo VALUES (78, 'Economy Plus', 'Aeroporto', 33.65, 'team@SkySprintAirlines.com', 'LMPZ', '2023-07-28 18:03:20', 'EYNK', '2023-07-28 20:31:57.220313', 4);
INSERT INTO public.volo VALUES (79, 'Business Deluxe', 'Aeroporto', 70.45, 'team@SkySprintAirlines.com', 'EYNK', '2023-07-28 20:48:57.220313', 'PLAZ', '2023-07-28 23:03:51.88914', 4);
INSERT INTO public.volo VALUES (82, 'Premium Economy', 'Aeroporto', 43.73, 'team@RiverRideCruises.com', 'LQVF', '2021-07-10 10:21:59', 'CPTP', '2021-07-10 11:59:58.867193', 7);
INSERT INTO public.volo VALUES (83, 'Business Deluxe', 'Aeroporto', 58.37, 'team@RiverRideCruises.com', 'CPTP', '2021-07-10 12:47:58.867193', 'SEJQ', '2021-07-10 16:02:30.817542', 7);
INSERT INTO public.volo VALUES (84, 'Economy Plus', 'Online', 27.98, 'team@RiverRideCruises.com', 'SEJQ', '2021-07-10 16:39:30.817542', 'GXTD', '2021-07-10 19:33:20.651268', 7);
INSERT INTO public.volo VALUES (88, 'Economy Standard', 'Aeroporto', 38.22, 'team@AquaJetFerries.com', 'AYBC', '2023-05-25 03:22:59', 'CHVW', '2023-05-25 05:11:12.419632', 7);
INSERT INTO public.volo VALUES (90, 'Premium Economy', 'Aeroporto', 44.50, 'team@SkySprintAirlines.com', 'MYBE', '2022-07-27 12:44:20', 'NQYH', '2022-07-27 15:00:24.462662', 10);
INSERT INTO public.volo VALUES (1, 'Business', 'Aeroporto', 34.39, 'team@RiverRideCruises.com', 'CHVW', '2020-10-27 17:12:16', 'KVXQ', '2020-10-27 19:08:39.883462', 7);
INSERT INTO public.volo VALUES (3, 'Business', 'Aeroporto', 43.64, 'team@SkySprintAirlines.com', 'YSEM', '2022-03-06 19:57:49', 'LQVF', '2022-03-06 21:47:50.903481', 5);
INSERT INTO public.volo VALUES (5, 'Prima Classe', 'Online', 63.36, 'team@SkySprintAirlines.com', 'YSEM', '2020-05-28 02:05:50', 'XBHY', '2020-05-28 03:48:54.540906', 14);
INSERT INTO public.volo VALUES (8, 'Business Deluxe', 'Online', 42.34, 'team@SkySprintAirlines.com', 'AUQJ', '2021-11-20 13:39:21', 'GKEE', '2021-11-20 16:24:32.816856', 5);
INSERT INTO public.volo VALUES (9, 'Economy Plus', 'Aeroporto', 31.91, 'team@SkySprintAirlines.com', 'GKEE', '2021-11-20 17:12:32.816856', 'TSIR', '2021-11-20 19:50:22.169752', 5);
INSERT INTO public.volo VALUES (11, 'Premium Economy', 'Aeroporto', 38.75, 'team@SkySprintAirlines.com', 'MYBE', '2020-04-04 06:57:37', 'YAAH', '2020-04-04 08:45:11.348117', 1);
INSERT INTO public.volo VALUES (13, 'Economy', 'Online', 39.50, 'team@AquaJetFerries.com', 'AUQJ', '2022-06-30 03:00:31', 'TZTM', '2022-06-30 05:12:36.054842', 3);
INSERT INTO public.volo VALUES (15, 'Business Deluxe', 'Online', 45.14, 'team@SkySprintAirlines.com', 'EHCX', '2022-04-13 16:23:27', 'GKEE', '2022-04-13 18:05:01.827693', 4);
INSERT INTO public.volo VALUES (18, 'Economy', 'Online', 24.79, 'team@RiverRideCruises.com', 'EHCX', '2022-04-13 22:47:35', 'GXTD', '2022-04-14 01:25:20.516246', 11);
INSERT INTO public.volo VALUES (19, 'Premium Economy', 'Aeroporto', 44.28, 'team@RiverRideCruises.com', 'GXTD', '2022-04-14 01:54:20.516246', 'DKHH', '2022-04-14 04:19:41.444149', 11);
INSERT INTO public.volo VALUES (21, 'Economy', 'Online', 30.36, 'team@AquaJetFerries.com', 'MYBE', '2020-04-04 11:11:09', 'OQOQ', '2020-04-04 13:34:14.978844', 14);
INSERT INTO public.volo VALUES (23, 'Business', 'Aeroporto', 48.39, 'team@AquaJetFerries.com', 'EHCX', '2022-04-13 08:57:57', 'YDHL', '2022-04-13 11:19:36.137996', 11);
INSERT INTO public.volo VALUES (25, 'Economy Standard', 'Aeroporto', 32.65, 'team@AquaJetFerries.com', 'BAPO', '2021-04-29 03:14:50', 'LNHV', '2021-04-29 04:56:24.494194', 8);
INSERT INTO public.volo VALUES (27, 'Premium Economy', 'Aeroporto', 41.84, 'team@SkySprintAirlines.com', 'EHCX', '2022-04-13 15:00:55', 'BAPO', '2022-04-13 17:23:06.682118', 0);
INSERT INTO public.volo VALUES (29, 'Business Deluxe', 'Aeroporto', 66.26, 'team@RiverRideCruises.com', 'YSEM', '2020-05-28 07:44:54', 'MMCC', '2020-05-28 10:04:13.879123', 11);
INSERT INTO public.volo VALUES (31, 'Economy Standard', 'Aeroporto', 28.67, 'team@AquaJetFerries.com', 'NQYH', '2022-08-05 14:46:02', 'HVNO', '2022-08-05 17:03:11.188446', 7);
INSERT INTO public.volo VALUES (33, 'Economy', 'Online', 20.21, 'team@RiverRideCruises.com', 'CWOJ', '2019-10-04 04:38:36', 'LQVF', '2019-10-04 06:40:35.428433', 3);
INSERT INTO public.volo VALUES (35, 'Economy Plus', 'Aeroporto', 40.76, 'team@RiverRideCruises.com', 'PLAZ', '2023-08-03 09:35:39', 'LNHV', '2023-08-03 12:05:20.189083', 5);
INSERT INTO public.volo VALUES (37, 'Economy Standard', 'Aeroporto', 38.35, 'team@SkySprintAirlines.com', 'NQYH', '2022-08-05 13:04:48', 'YQXL', '2022-08-05 15:29:48.14869', 10);
INSERT INTO public.volo VALUES (39, 'Economy', 'Aeroporto', 27.05, 'team@AquaJetFerries.com', 'YSEM', '2020-05-28 05:36:33', 'TZTM', '2020-05-28 07:10:56.098106', 4);
INSERT INTO public.volo VALUES (42, 'Economy Plus', 'Online', 25.04, 'team@SkySprintAirlines.com', 'AUQJ', '2022-06-30 08:00:16', 'EYNK', '2022-06-30 10:28:48.563082', 7);
INSERT INTO public.volo VALUES (43, 'Business', 'Aeroporto', 39.32, 'team@SkySprintAirlines.com', 'EYNK', '2022-06-30 10:45:48.563082', 'ITLG', '2022-06-30 13:09:11.224382', 7);
INSERT INTO public.volo VALUES (45, 'Economy Plus', 'Aeroporto', 34.53, 'team@SkySprintAirlines.com', 'GXTD', '2021-07-19 14:34:40', 'PCWM', '2021-07-19 16:41:50.759506', 5);
INSERT INTO public.volo VALUES (47, 'Business Deluxe', 'Online', 70.51, 'team@RiverRideCruises.com', 'NQYH', '2022-08-05 05:05:25', 'JPXU', '2022-08-05 07:27:18.233039', 14);
INSERT INTO public.volo VALUES (49, 'Economy Standard', 'Aeroporto', 26.76, 'team@AquaJetFerries.com', 'AUQJ', '2022-06-30 03:22:02', 'YSEM', '2022-06-30 05:26:48.646091', 7);
INSERT INTO public.volo VALUES (51, 'Premium Economy', 'Aeroporto', 46.78, 'team@AquaJetFerries.com', 'AUQJ', '2021-11-20 23:33:57', 'EHCX', '2021-11-21 01:04:37.691102', 8);
INSERT INTO public.volo VALUES (53, 'Prima Classe', 'Aeroporto', 59.90, 'team@AquaJetFerries.com', 'BAPO', '2021-04-29 03:01:38', 'YAAH', '2021-04-29 05:24:02.779997', 2);
INSERT INTO public.volo VALUES (56, 'Economy', 'Aeroporto', 28.49, 'team@RiverRideCruises.com', 'NQYH', '2022-08-05 23:15:40', 'ICXW', '2022-08-06 01:54:09.888562', 0);
INSERT INTO public.volo VALUES (57, 'Economy Plus', 'Aeroporto', 41.22, 'team@RiverRideCruises.com', 'ICXW', '2022-08-06 02:38:09.888562', 'TZTM', '2022-08-06 04:40:28.390042', 0);
INSERT INTO public.volo VALUES (59, 'Business Deluxe', 'Aeroporto', 44.26, 'team@SkySprintAirlines.com', 'CHVW', '2023-05-31 03:19:02', 'YQXL', '2023-05-31 05:07:56.725276', 8);
INSERT INTO public.volo VALUES (61, 'Business', 'Online', 59.99, 'team@RiverRideCruises.com', 'CWOJ', '2019-10-04 02:21:19', 'YDHL', '2019-10-04 04:19:00.309245', 0);
INSERT INTO public.volo VALUES (63, 'Business', 'Aeroporto', 50.63, 'team@RiverRideCruises.com', 'MYBE', '2021-06-09 11:08:09', 'EWKJ', '2021-06-09 12:44:20.680341', 2);
INSERT INTO public.volo VALUES (67, 'Business', 'Online', 32.63, 'team@SkySprintAirlines.com', 'CHVW', '2021-05-27 09:35:37', 'YDHL', '2021-05-27 12:50:46.446454', 7);
INSERT INTO public.volo VALUES (68, 'Business Deluxe', 'Aeroporto', 70.00, 'team@SkySprintAirlines.com', 'YDHL', '2021-05-27 13:47:46.446454', 'ICXW', '2021-05-27 16:26:15.459465', 7);
INSERT INTO public.volo VALUES (69, 'Economy Plus', 'Online', 36.14, 'team@SkySprintAirlines.com', 'ICXW', '2021-05-27 16:43:15.459465', 'YQXL', '2021-05-27 20:00:45.147902', 7);
INSERT INTO public.volo VALUES (71, 'Economy Plus', 'Aeroporto', 40.15, 'team@RiverRideCruises.com', 'CHVW', '2023-05-31 20:05:13', 'HEKS', '2023-05-31 22:03:41.496871', 0);
INSERT INTO public.volo VALUES (73, 'Business', 'Aeroporto', 59.40, 'team@SkySprintAirlines.com', 'BAPO', '2021-04-29 07:45:53', 'EHCX', '2021-04-29 10:02:30.017221', 14);
INSERT INTO public.volo VALUES (75, 'Economy', 'Aeroporto', 31.66, 'team@SkySprintAirlines.com', 'CHVW', '2021-05-27 08:35:16', 'TSIR', '2021-05-27 10:47:25.332121', 1);
INSERT INTO public.volo VALUES (77, 'Economy', 'Online', 23.31, 'team@AquaJetFerries.com', 'EHCX', '2022-09-08 21:45:58', 'LMPZ', '2022-09-09 00:02:46.977774', 14);
INSERT INTO public.volo VALUES (80, 'Economy Standard', 'Online', 26.35, 'team@SkySprintAirlines.com', 'PLAZ', '2023-08-03 05:10:19', 'ZVXI', '2023-08-03 07:55:42.307696', 4);
INSERT INTO public.volo VALUES (81, 'Economy', 'Online', 26.67, 'team@SkySprintAirlines.com', 'ZVXI', '2023-08-03 08:49:42.307696', 'LMPZ', '2023-08-03 11:30:25.405467', 4);
INSERT INTO public.volo VALUES (85, 'Prima Classe', 'Aeroporto', 79.28, 'team@RiverRideCruises.com', 'GXTD', '2021-07-19 16:58:37', 'OQOQ', '2021-07-19 20:14:20.342141', 7);
INSERT INTO public.volo VALUES (86, 'Business', 'Online', 30.74, 'team@RiverRideCruises.com', 'OQOQ', '2021-07-19 20:39:20.342141', 'FKYC', '2021-07-19 23:40:47.093825', 7);
INSERT INTO public.volo VALUES (87, 'Economy', 'Aeroporto', 33.40, 'team@RiverRideCruises.com', 'FKYC', '2021-07-20 00:36:47.093825', 'LQVF', '2021-07-20 03:40:09.18338', 7);
INSERT INTO public.volo VALUES (89, 'Business', 'Aeroporto', 49.41, 'team@AquaJetFerries.com', 'CHVW', '2023-05-31 23:10:08', 'AYBC', '2023-06-01 00:52:58.854224', 7);
INSERT INTO public.volo VALUES (91, 'Business', 'Online', 53.03, 'team@SkySprintAirlines.com', 'NQYH', '2022-08-05 20:24:19', 'MYBE', '2022-08-05 22:23:18.931692', 10);


--
-- TOC entry 3338 (class 2606 OID 16715)
-- Name: aeroporto aeroporto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aeroporto
    ADD CONSTRAINT aeroporto_pkey PRIMARY KEY (codice);


--
-- TOC entry 3336 (class 2606 OID 16705)
-- Name: agenzia agenzia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agenzia
    ADD CONSTRAINT agenzia_pkey PRIMARY KEY (email);


--
-- TOC entry 3334 (class 2606 OID 16689)
-- Name: alloggio alloggio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alloggio
    ADD CONSTRAINT alloggio_pkey PRIMARY KEY (id_citta, nome);


--
-- TOC entry 3353 (class 2606 OID 16833)
-- Name: andata andata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.andata
    ADD CONSTRAINT andata_pkey PRIMARY KEY (codice_transazione, codice_volo);


--
-- TOC entry 3332 (class 2606 OID 16683)
-- Name: citta citta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.citta
    ADD CONSTRAINT citta_pkey PRIMARY KEY (id);


--
-- TOC entry 3322 (class 2606 OID 16649)
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (email);


--
-- TOC entry 3324 (class 2606 OID 16660)
-- Name: compagnia compagnia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compagnia
    ADD CONSTRAINT compagnia_pkey PRIMARY KEY (email);


--
-- TOC entry 3318 (class 2606 OID 16641)
-- Name: dati_cliente dati_cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dati_cliente
    ADD CONSTRAINT dati_cliente_pkey PRIMARY KEY (email_cliente);


--
-- TOC entry 3320 (class 2606 OID 16643)
-- Name: dati_cliente dati_cliente_telefono_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dati_cliente
    ADD CONSTRAINT dati_cliente_telefono_key UNIQUE (telefono);


--
-- TOC entry 3330 (class 2606 OID 16678)
-- Name: descrizione descrizione_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.descrizione
    ADD CONSTRAINT descrizione_pkey PRIMARY KEY (id);


--
-- TOC entry 3326 (class 2606 OID 16666)
-- Name: informazioni_bagagli informazioni_bagagli_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.informazioni_bagagli
    ADD CONSTRAINT informazioni_bagagli_pkey PRIMARY KEY (id);


--
-- TOC entry 3349 (class 2606 OID 16806)
-- Name: informazioni_trasporto informazioni_trasporto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.informazioni_trasporto
    ADD CONSTRAINT informazioni_trasporto_pkey PRIMARY KEY (codice_transazione);


--
-- TOC entry 3345 (class 2606 OID 16758)
-- Name: pacchetto_viaggio pacchetto_viaggio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacchetto_viaggio
    ADD CONSTRAINT pacchetto_viaggio_pkey PRIMARY KEY (id);


--
-- TOC entry 3328 (class 2606 OID 16673)
-- Name: polizza polizza_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polizza
    ADD CONSTRAINT polizza_pkey PRIMARY KEY (id);


--
-- TOC entry 3347 (class 2606 OID 16785)
-- Name: prenotazione prenotazione_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prenotazione
    ADD CONSTRAINT prenotazione_pkey PRIMARY KEY (codice_transazione);


--
-- TOC entry 3355 (class 2606 OID 16849)
-- Name: recensione recensione_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_pkey PRIMARY KEY (id);


--
-- TOC entry 3351 (class 2606 OID 16817)
-- Name: ritorno ritorno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ritorno
    ADD CONSTRAINT ritorno_pkey PRIMARY KEY (codice_transazione, codice_volo);


--
-- TOC entry 3340 (class 2606 OID 16726)
-- Name: transazione transazione_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transazione
    ADD CONSTRAINT transazione_pkey PRIMARY KEY (codice);


--
-- TOC entry 3342 (class 2606 OID 16732)
-- Name: volo volo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.volo
    ADD CONSTRAINT volo_pkey PRIMARY KEY (codice);


--
-- TOC entry 3343 (class 1259 OID 16860)
-- Name: idx_pxalloggi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pxalloggi ON public.pacchetto_viaggio USING btree (id_descrizione, id_citta_alloggio, nome_alloggio);


--
-- TOC entry 3360 (class 2606 OID 16716)
-- Name: aeroporto aeroporto_id_citta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aeroporto
    ADD CONSTRAINT aeroporto_id_citta_fkey FOREIGN KEY (id_citta) REFERENCES public.citta(id) ON UPDATE CASCADE;


--
-- TOC entry 3359 (class 2606 OID 16706)
-- Name: agenzia agenzia_id_citta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agenzia
    ADD CONSTRAINT agenzia_id_citta_fkey FOREIGN KEY (id_citta) REFERENCES public.citta(id) ON UPDATE CASCADE;


--
-- TOC entry 3357 (class 2606 OID 16690)
-- Name: alloggio alloggio_id_citta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alloggio
    ADD CONSTRAINT alloggio_id_citta_fkey FOREIGN KEY (id_citta) REFERENCES public.citta(id) ON UPDATE CASCADE;


--
-- TOC entry 3358 (class 2606 OID 16695)
-- Name: alloggio alloggio_id_descrizione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alloggio
    ADD CONSTRAINT alloggio_id_descrizione_fkey FOREIGN KEY (id_descrizione) REFERENCES public.descrizione(id) ON UPDATE CASCADE;


--
-- TOC entry 3375 (class 2606 OID 16834)
-- Name: andata andata_codice_transazione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.andata
    ADD CONSTRAINT andata_codice_transazione_fkey FOREIGN KEY (codice_transazione) REFERENCES public.informazioni_trasporto(codice_transazione) ON UPDATE CASCADE;


--
-- TOC entry 3376 (class 2606 OID 16839)
-- Name: andata andata_codice_volo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.andata
    ADD CONSTRAINT andata_codice_volo_fkey FOREIGN KEY (codice_volo) REFERENCES public.volo(codice) ON UPDATE CASCADE;


--
-- TOC entry 3356 (class 2606 OID 16650)
-- Name: cliente cliente_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_email_fkey FOREIGN KEY (email) REFERENCES public.dati_cliente(email_cliente) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3372 (class 2606 OID 16807)
-- Name: informazioni_trasporto informazioni_trasporto_codice_transazione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.informazioni_trasporto
    ADD CONSTRAINT informazioni_trasporto_codice_transazione_fkey FOREIGN KEY (codice_transazione) REFERENCES public.prenotazione(codice_transazione) ON UPDATE CASCADE;


--
-- TOC entry 3365 (class 2606 OID 16759)
-- Name: pacchetto_viaggio pacchetto_viaggio_email_agenzia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacchetto_viaggio
    ADD CONSTRAINT pacchetto_viaggio_email_agenzia_fkey FOREIGN KEY (email_agenzia) REFERENCES public.agenzia(email) ON UPDATE CASCADE;


--
-- TOC entry 3366 (class 2606 OID 16774)
-- Name: pacchetto_viaggio pacchetto_viaggio_id_citta_alloggio_nome_alloggio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacchetto_viaggio
    ADD CONSTRAINT pacchetto_viaggio_id_citta_alloggio_nome_alloggio_fkey FOREIGN KEY (id_citta_alloggio, nome_alloggio) REFERENCES public.alloggio(id_citta, nome) ON UPDATE CASCADE;


--
-- TOC entry 3367 (class 2606 OID 16769)
-- Name: pacchetto_viaggio pacchetto_viaggio_id_descrizione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacchetto_viaggio
    ADD CONSTRAINT pacchetto_viaggio_id_descrizione_fkey FOREIGN KEY (id_descrizione) REFERENCES public.descrizione(id) ON UPDATE CASCADE;


--
-- TOC entry 3368 (class 2606 OID 16764)
-- Name: pacchetto_viaggio pacchetto_viaggio_id_polizza_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacchetto_viaggio
    ADD CONSTRAINT pacchetto_viaggio_id_polizza_fkey FOREIGN KEY (id_polizza) REFERENCES public.polizza(id) ON UPDATE CASCADE;


--
-- TOC entry 3369 (class 2606 OID 16791)
-- Name: prenotazione prenotazione_codice_transazione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prenotazione
    ADD CONSTRAINT prenotazione_codice_transazione_fkey FOREIGN KEY (codice_transazione) REFERENCES public.transazione(codice) ON UPDATE CASCADE;


--
-- TOC entry 3370 (class 2606 OID 16786)
-- Name: prenotazione prenotazione_email_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prenotazione
    ADD CONSTRAINT prenotazione_email_cliente_fkey FOREIGN KEY (email_cliente) REFERENCES public.cliente(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3371 (class 2606 OID 16796)
-- Name: prenotazione prenotazione_id_pacchetto_viaggio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prenotazione
    ADD CONSTRAINT prenotazione_id_pacchetto_viaggio_fkey FOREIGN KEY (id_pacchetto_viaggio) REFERENCES public.pacchetto_viaggio(id) ON UPDATE CASCADE;


--
-- TOC entry 3377 (class 2606 OID 16850)
-- Name: recensione recensione_email_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_email_cliente_fkey FOREIGN KEY (email_cliente) REFERENCES public.cliente(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3378 (class 2606 OID 16855)
-- Name: recensione recensione_id_citta_alloggio_nome_alloggio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_id_citta_alloggio_nome_alloggio_fkey FOREIGN KEY (id_citta_alloggio, nome_alloggio) REFERENCES public.alloggio(id_citta, nome) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3373 (class 2606 OID 16818)
-- Name: ritorno ritorno_codice_transazione_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ritorno
    ADD CONSTRAINT ritorno_codice_transazione_fkey FOREIGN KEY (codice_transazione) REFERENCES public.informazioni_trasporto(codice_transazione) ON UPDATE CASCADE;


--
-- TOC entry 3374 (class 2606 OID 16823)
-- Name: ritorno ritorno_codice_volo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ritorno
    ADD CONSTRAINT ritorno_codice_volo_fkey FOREIGN KEY (codice_volo) REFERENCES public.volo(codice) ON UPDATE CASCADE;


--
-- TOC entry 3361 (class 2606 OID 16743)
-- Name: volo volo_aeroporto_arrivo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.volo
    ADD CONSTRAINT volo_aeroporto_arrivo_fkey FOREIGN KEY (aeroporto_arrivo) REFERENCES public.aeroporto(codice) ON UPDATE CASCADE;


--
-- TOC entry 3362 (class 2606 OID 16738)
-- Name: volo volo_aeroporto_partenza_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.volo
    ADD CONSTRAINT volo_aeroporto_partenza_fkey FOREIGN KEY (aeroporto_partenza) REFERENCES public.aeroporto(codice) ON UPDATE CASCADE;


--
-- TOC entry 3363 (class 2606 OID 16733)
-- Name: volo volo_email_compagnia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.volo
    ADD CONSTRAINT volo_email_compagnia_fkey FOREIGN KEY (email_compagnia) REFERENCES public.compagnia(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3364 (class 2606 OID 16748)
-- Name: volo volo_id_bagagli_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.volo
    ADD CONSTRAINT volo_id_bagagli_fkey FOREIGN KEY (id_bagagli) REFERENCES public.informazioni_bagagli(id) ON UPDATE CASCADE;

--
-- PostgreSQL database dump complete
--




--
--	Query (commentate)
--
/*
-- Trovare tutti i clienti che hanno effettuato almeno una recensione con un voto
-- superiore o uguale a x stelle, riportare il loro: nome, cognome e l'email, e specificare il nome dell'alloggio per cui 
-- è stata scritta la recensione, il giudizio dato e la motivazione se disponibile, nel caso tale informazione non fosse
-- disponibile sostituire NULL con la stringa: '* Nessuna motivazione fornita'. Per l'esempio x = 3

SELECT D.NOME, D.COGNOME, A.NOME, R.GIUDIZIO, COALESCE(R.MOTIVAZIONE,'* Nessuna motivazione fornita') AS MOTIVAZIONE
  FROM DATI_CLIENTE AS D JOIN CLIENTE AS C ON D.EMAIL_CLIENTE = C.EMAIL
  JOIN RECENSIONE AS R ON C.EMAIL = R.EMAIL_CLIENTE
  JOIN ALLOGGIO AS A ON R.ID_CITTA_ALLOGGIO = A.ID_CITTA AND R.NOME_ALLOGGIO = A.NOME
 WHERE GIUDIZIO >= 3;
 
 -- Per ciascuna compagnia aerea fornire: il nome della compagnia, il numero di prenotazioni, il numero totale di voli
-- che sono stati prenotati compagnia aerea, la media prezzi dei voli offerti, il prezzo massimo devi voli offerti,
-- e il prezzo minimo dei voli offerto. Filtrare la ricerca in modo da mostrare solo le compagnia con
-- almeno x voli. In fine si riordini in modo decrescente per numero voli. Esempio: x = 10

SELECT C.NOME AS NOME_COMPAGNIA,
       COUNT(V.CODICE) AS NUMERO_VOLI,
       AVG(V.PREZZO) AS MEDIA_PREZZO_VOLO,
       MAX(V.PREZZO) AS PREZZO_MASSIMO,
       MIN(V.PREZZO) AS PREZZO_MINIMO
  FROM COMPAGNIA C
  JOIN VOLO AS V
    ON C.EMAIL = V.EMAIL_COMPAGNIA
 GROUP BY C.NOME
HAVING COUNT(V.CODICE) >= 10
 ORDER BY NUMERO_VOLI DESC;
 
 
-- Riportare per ogni agenzia il numero di pacchetti offerti, in media quanto costano i loro pacchetti e la media delle
-- recensioni ricevute sugli alloggi offerti

SELECT AGENZIA.DENOMINAZIONE,
       NUMERO_OFFERTE.CONTEGGIO AS NUMERO_PACCHETTI,
       ROUND(MEDIA_PREZZI.MEDIA,2) AS PREZZO_MEDIO,
       ROUND(MEDIA_REC.MEDIA,2) as MEDIA_RECENSIONI
  FROM
        (SELECT EMAIL_AGENZIA AS EMAIL,
               COUNT(*) AS CONTEGGIO
          FROM PACCHETTO_VIAGGIO
         GROUP BY EMAIL_AGENZIA
       ) AS NUMERO_OFFERTE,
       
        (SELECT EMAIL_AGENZIA AS EMAIL,
               AVG(PACCHETTO_VIAGGIO.PREZZO) AS MEDIA
          FROM PACCHETTO_VIAGGIO
         GROUP BY EMAIL_AGENZIA
       ) AS MEDIA_PREZZI,

        (SELECT EMAIL_AGENZIA AS EMAIL,
               AVG(R.GIUDIZIO) AS MEDIA
          FROM RECENSIONE AS R
          JOIN PACCHETTO_VIAGGIO AS P
            ON P.ID_CITTA_ALLOGGIO = R.ID_CITTA_ALLOGGIO
           AND P.NOME_ALLOGGIO = R.NOME_ALLOGGIO
         GROUP BY P.EMAIL_AGENZIA
       ) AS MEDIA_REC,
       AGENZIA

 WHERE NUMERO_OFFERTE.EMAIL = MEDIA_PREZZI.EMAIL
   AND MEDIA_PREZZI.EMAIL = MEDIA_REC.EMAIL
   AND MEDIA_REC.EMAIL = AGENZIA.EMAIL;
   
   
-- Dato un cliente. Per ogni acquisto recuperare: tutte le informazioni della transizione, il totale per il trasporto,
-- il costo di base del pacchetto a persona, il numero di persone partecipanti e il numero di voli per quel viaggio.
-- Si includano inoltre anche i casi in cui non hanno prenotato il trasporto attraverso il servizio, e si riporti in quel
-- caso il valore 0, sia per il totale trasporto che per il numero di voli.
-- Cliente per l'esempio: Annunziata.Fornaciari@email.com
 
SELECT DATI_PRENOTAZIONE.CODICE, 
       DATI_PRENOTAZIONE.NUMERO_PERSONE AS NUMERO_PARTECIPANTI, 
       DATI_PRENOTAZIONE.BANCA, 
       DATI_PRENOTAZIONE.IMPORTO, 
       DATI_PRENOTAZIONE.CIRCUITO, 
       DATI_PRENOTAZIONE.DATAORA, 
       DATI_PRENOTAZIONE.PREZZO AS PREZZO_PACCHETTO, 
       COALESCE(INFO_TRASPORTO.PREZZO_TOTALE, 
           0) AS TOTALE_TRASPORTO, 
       COALESCE(INFO_TRASPORTO.VOLI_TOTALI, 
           0) AS VOLI_PRESI 
  FROM 
        (SELECT I.CODICE_TRANSAZIONE AS CODICE,      
               I.PREZZO_TOTALE, 
               DATI_VOLI.VOLI_TOTALI 
          FROM 
                (SELECT ANDATA_RITORNO.CODICE_TRANSAZIONE,   
                       COUNT(*) AS VOLI_TOTALI 
                  FROM 
                        (SELECT * 
                          FROM ANDATA 
                     UNION ALL SELECT * 
                          FROM RITORNO
                       ) AS ANDATA_RITORNO 
                 GROUP BY ANDATA_RITORNO.CODICE_TRANSAZIONE
               ) AS DATI_VOLI, 
               INFORMAZIONI_TRASPORTO AS I 
         WHERE I.CODICE_TRANSAZIONE = DATI_VOLI.CODICE_TRANSAZIONE 
       ) AS INFO_TRASPORTO 

 RIGHT JOIN 
        (SELECT T.CODICE, 
               T.DATAORA, 
               T.IMPORTO, 
               T.CIRCUITO, 
               T.BANCA, 
               P.NUMERO_PERSONE, 
               PV.PREZZO 
          FROM PRENOTAZIONE AS P, 
               TRANSAZIONE AS T, 
               PACCHETTO_VIAGGIO AS PV 
         WHERE 'Annunziata.Fornaciari@email.com' = P.EMAIL_CLIENTE
           AND P.CODICE_TRANSAZIONE = T.CODICE
           AND PV.ID = P.ID_PACCHETTO_VIAGGIO
       ) AS DATI_PRENOTAZIONE
    ON INFO_TRASPORTO.CODICE = DATI_PRENOTAZIONE.CODICE;
    

-- Algoritmo per mostrare i pacchetti: fornita una data, cercare tutti i pacchetti viaggio che si svolgono dopo quella
-- data. Eliminare i pacchetti che non sono più disponibili (perché già prenotati tutti) dai risultati. Riportare le
-- seguenti informazioni essenziali: il titolo della descrizione del pacchetto, la data di partenza, la data di ritorno,
-- il prezzo, il numero di persone, il nome dell'alloggio, la destinazione e la polizza. In fine si filtri i risultati lasciando
-- tutti i pacchetti compresi dal prezzo in un intevervallo di prezzo. Ordinarli per data di partenza in ordine crescente.
-- Esempio con la data 2019-10-11, intrevallo prezzo [300, 1000].
 
 
SELECT D.TITOLO, 
       DISPONIBILI.PREZZO, 
       DISPONIBILI.NUMERO_PERSONE, 
       DISPONIBILI.DATA_PARTENZA, 
       DISPONIBILI.DATA_RITORNO, 
       DISPONIBILI.NOME_ALLOGGIO, 
       C.NOME AS NOME_CITTA, 
       C.STATO

  FROM 
        (SELECT P.ID, 
               P.PREZZO, 
               P.NUMERO_PERSONE, 
               P.DATA_PARTENZA, 
               P.DATA_RITORNO, 
               P.ID_DESCRIZIONE, 
               P.ID_CITTA_ALLOGGIO, 
               P.NOME_ALLOGGIO 
     
          FROM 
                (SELECT ID_PACCHETTO_VIAGGIO AS ID, 
                       COUNT(*) AS PRENOTAZIONI_TOTALI 
                  FROM PRENOTAZIONE 
                 GROUP BY ID_PACCHETTO_VIAGGIO
               ) AS CONTEGGIO_PRENOTAZIONI, 
               PACCHETTO_VIAGGIO AS P 
         WHERE P.ID = CONTEGGIO_PRENOTAZIONI.ID
           AND P.DISPONIBILITA > CONTEGGIO_PRENOTAZIONI.PRENOTAZIONI_TOTALI  
           AND P.DATA_PARTENZA > '11-04-2021'
       ) AS DISPONIBILI,
       
       DESCRIZIONE AS D,
       CITTA AS C
       
 WHERE D.ID = DISPONIBILI.ID_DESCRIZIONE
   AND C.ID = DISPONIBILI.ID_CITTA_ALLOGGIO
   AND DISPONIBILI.PREZZO > 300
   AND DISPONIBILI.PREZZO < 1000
 ORDER BY DISPONIBILI.DATA_PARTENZA;
 
 
-- Si trovi tutti i voli da una aeroporto x ad un aeroporto y che attraverso gli scali costano meno del
-- viaggio diretto. Di ogni volo con scalo si riporti solo il codice del volo di partenza, la data/ora di partenza,
-- il codice del volo di arrivo, la data/ora di arrivo, il numero di scali, il prezzo contando tutti voli
-- dello scalo, il risparmio (differenza totale con scali e senza scali), il tempo totale di viaggio (
-- somma dei voli, senza contare le attese al terminale). Nota: il totale prezzo dei voli è per persona.
-- Nell'esempio: x.codice = 'LQVF' e y.codice = 'YSEM'

WITH RECURSIVE POSSIBILI_SCALI(
    PRIMO_VOLO, -- Tiene traccia della partenza
    VOLO_ATTUALE,
    AEROPORTO_PARTENZA,
    TIMESTAMP_PARTENZA,
    AEROPORTO_ARRIVO,
    TIMESTAMP_ARRIVO,
    NUMERO_SCALI,
    TOTALE_PREZZO,
    DURATA_TOTALE_VIAGGIO
) AS (
    (
        SELECT
            VOLO.CODICE AS PRIMO_VOLO,
            VOLO.CODICE AS VOLO_ATTUALE,
            AEROPORTO_PARTENZA,
            TIMESTAMP_PARTENZA,
            AEROPORTO_ARRIVO,
            TIMESTAMP_ARRIVO,
            0 AS NUMERO_SCALI,
            CAST(
                VOLO.PREZZO AS NUMERIC(
                    7,
                    2
                )
            ) AS TOTALE_PREZZO,
            (TIMESTAMP_ARRIVO - TIMESTAMP_PARTENZA) AS DURATA_TOTALE_VIAGGIO
        FROM
            VOLO
    )
    UNION
    ALL --Ricorsione
    (
        SELECT
            POSSIBILI_SCALI.PRIMO_VOLO,
            SUCCESSIVO.CODICE AS VOLO_ATTUALE,
            SUCCESSIVO.AEROPORTO_PARTENZA,
            SUCCESSIVO.TIMESTAMP_PARTENZA,
            SUCCESSIVO.AEROPORTO_ARRIVO,
            SUCCESSIVO.TIMESTAMP_ARRIVO,
            POSSIBILI_SCALI.NUMERO_SCALI + 1 AS NUMERO_SCALI,
            CAST(
                POSSIBILI_SCALI.TOTALE_PREZZO + SUCCESSIVO.PREZZO AS NUMERIC(
                    7,
                    2
                )
            ) AS TOTALE_PREZZO,
            (
                POSSIBILI_SCALI.DURATA_TOTALE_VIAGGIO + (
                    SUCCESSIVO.TIMESTAMP_ARRIVO - SUCCESSIVO.TIMESTAMP_PARTENZA
                )
            ) AS DURATA_TOTALE_VIAGGIO
        FROM
            VOLO AS SUCCESSIVO,
            POSSIBILI_SCALI
        WHERE
            SUCCESSIVO.AEROPORTO_PARTENZA = POSSIBILI_SCALI.AEROPORTO_ARRIVO
            AND SUCCESSIVO.TIMESTAMP_PARTENZA > POSSIBILI_SCALI.TIMESTAMP_ARRIVO
    )
) -- Nota: tra le tuple di possibili_scali ci sono anche i voli diretti
SELECT
    DIRETTO.PRIMO_VOLO AS DIRETTO,
    DIRETTO.TIMESTAMP_PARTENZA AS D_PARTENZA,
    DIRETTO.TIMESTAMP_ARRIVO AS D_ARRIVO,
    DIRETTO.TOTALE_PREZZO AS D_PREZZO,
    SCALI.PRIMO_VOLO AS S_PARTENZA_CODICE,
    SCALI.VOLO_ATTUALE AS S_ARRIVO_CODICE,
    V.TIMESTAMP_PARTENZA AS S_PARTENZA,
    SCALI.TIMESTAMP_ARRIVO AS S_ARRIVO,
    SCALI.NUMERO_SCALI,
    SCALI.TOTALE_PREZZO AS SCALO_PREZZO,
    SCALI.DURATA_TOTALE_VIAGGIO
FROM
    POSSIBILI_SCALI AS DIRETTO,
    POSSIBILI_SCALI AS SCALI,
    VOLO AS V -- V Serve a ottenere le informazioni del primo volo di partenza
WHERE
    DIRETTO.NUMERO_SCALI = 0
    AND DIRETTO.AEROPORTO_PARTENZA = 'LQVF'
    AND DIRETTO.AEROPORTO_ARRIVO = 'YSEM'
    AND DIRETTO.TOTALE_PREZZO > SCALI.TOTALE_PREZZO
    AND SCALI.NUMERO_SCALI > 0
    AND SCALI.AEROPORTO_ARRIVO = DIRETTO.AEROPORTO_ARRIVO
    AND SCALI.PRIMO_VOLO = V.CODICE;
*/
